// const baseUrl = "http://localhost:3000/api/v1";
const baseUrl = "http://192.168.100.29:3001/api/v1";

export default baseUrl;
