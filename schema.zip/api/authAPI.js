import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import baseUrl from "./apiConfig";
export const authApi = createApi({
  reducerPath: "authApi",
  baseQuery: fetchBaseQuery({ baseUrl }),
  endpoints: (builder) => ({
    signIn: builder.mutation({
      query: (credentials) => ({
        url: "auth/login",
        method: "POST",
        body: credentials,
      }),
    }),
    googleLogin: builder.mutation({
      query: (credentials) => ({
        url: "auth/google-callback",
        method: "POST",
        body: credentials,
      }),
    }),
    sendEmail: builder.mutation({
      query: (credentials) => ({
        url: "auth/send-email",
        method: "POST",
        body: credentials,
      }),
    }),
    resetPassword: builder.mutation({
      query: (credentials) => ({
        url: "auth/reset-password",
        method: "PUT",
        body: credentials,
      }),
    }),
    getUserProfile: builder.query({
      query: () => "user/profile",
    }),
  }),
});

export const {
  useSignInMutation,
  useSendEmailMutation,
  useResetPasswordMutation,
  useGetUserProfileQuery,
  useGoogleLoginMutation,
} = authApi;
