// src/api/meetingAPI.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { baseQueryWithReauth } from "./apiUtils";
export const meetingApi = createApi({
  reducerPath: "meetingApi",
  baseQuery: baseQueryWithReauth,
  tagTypes: ["Meeting , Create"],
  endpoints: (builder) => ({
    getMeeting: builder.query({
      query: (userId, filter) =>
      `user-meeting/meeting/${userId}?userStaus=${filter}`,
      providesTags: ["Create"],
    }),
    getMeetingSlots: builder.query({
      query: (userId, filter) =>
      `user-meeting/meeting/${userId}?userStaus=${filter}`,
    }),
    getPracticeInterviews: builder.query({
      query: (userId) => `user-meeting/user/${userId}`,
      providesTags: ["Meeting"],
    }),
    createMeeting: builder.mutation({
      query: (newMeeting) => ({
        url: "user-meeting",
        method: "POST",
        body: newMeeting,
      }),
      invalidatesTags: ["Create"],
    }),
    acceptMeeting: builder.mutation({
      query: (meetingId) => ({
        url: `user-meeting/accept-meeting/${meetingId}`,
        method: "PUT",
        body: {},
      }),
      invalidatesTags: ["Meeting"],
    }),
  }),
});

export const {
  useGetMeetingQuery,
  useGetMeetingSlotsQuery,
  useCreateMeetingMutation,
  useAcceptMeetingMutation,
  useGetPracticeInterviewsQuery,
} = meetingApi;
