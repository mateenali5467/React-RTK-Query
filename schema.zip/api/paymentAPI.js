// src/api/userApi.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { baseQueryWithReauth } from "./apiUtils";
export const paymentApi = createApi({
  reducerPath: "paymentApi",
  baseQuery: baseQueryWithReauth,
  tagTypes: ["Delete" , "UpdatePlan"],
  endpoints: (builder) => ({
    getInvoices: builder.query({
      query: (userId) => `payment/all-invoices/${userId}`,
      providesTags: ["UpdatePlan"],
    }),
    getCard: builder.query({
      query: () => `payment/all-cards`,
      providesTags: ["Delete"],
    }),
    createUser: builder.mutation({
      query: (newUser) => ({
        url: "user",
        method: "POST",
        body: newUser,
      }),
    }),
    addCard: builder.mutation({
      query: ({ userId, data }) => ({
        url: `payment/add-card/${userId}`,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Delete"],
    }),
    createCustomer: builder.mutation({
      query: ({ userId, subscriptionPlan }) => ({
        url: `payment/create-customer/${userId}`,
        method: "POST",
        body: subscriptionPlan,
      }),
    }),
    updatePlan: builder.mutation({
      query: ({ userId, subscriptionPlan }) => ({
        url: `payment/update-plan/${userId}`,
        method: "POST",
        body: subscriptionPlan,
      }),
      invalidatesTags: ["UpdatePlan"],

    }),
    deleteCard: builder.mutation({
      query: (cardId) => ({
        url: `/payment/delete-card/${cardId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Delete"],
    }),
  }),
});

export const {
  useGetInvoicesQuery,
  useGetCardQuery,
  useCreateUserMutation,
  useCreateCustomerMutation,
  useUpdatePlanMutation,
  useAddCardMutation,
  useDeleteCardMutation,
} = paymentApi;
