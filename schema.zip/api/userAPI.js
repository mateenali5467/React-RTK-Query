// src/api/userApi.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { baseQueryWithReauth } from "./apiUtils";
export const userApi = createApi({
  reducerPath: "userApi",
  baseQuery: baseQueryWithReauth,
  endpoints: (builder) => ({
    getUser: builder.query({
      query: (userId) => `user/${userId}`,
    }),
    createUser: builder.mutation({
      query: (newUser) => ({
        url: "user",
        method: "POST",
        body: newUser,
      }),
    }),
    optVerified: builder.mutation({
      query: (data) => ({
        url: "user/opt-verfied",
        method: "POST",
        body: data,
      }),
    }),
    updateUser: builder.mutation({
      query: ({ userId, updatedUser }) => ({
        url: `user/${userId}`,
        method: "PUT",
        body: updatedUser,
        // headers: {
        //   "Content-Type": "multipart/form-data;",
        // },
      }),
    }),
    deleteUser: builder.mutation({
      query: (userId) => ({
        url: `users/${userId}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useGetUserQuery,
  useCreateUserMutation,
  useUpdateUserMutation,
  useDeleteUserMutation,
  useOptVerifiedMutation,
} = userApi;
