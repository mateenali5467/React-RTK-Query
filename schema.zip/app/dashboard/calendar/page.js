"use client";
import React, { useState } from "react";
import { Calendar, dateFnsLocalizer } from "react-big-calendar";
import { Box, Button, Typography, Popover } from "@mui/material";
import enUS from "date-fns/locale/en-US";
import { format, parse, startOfWeek, getDay } from "date-fns";
import Container from "@/components/layouts/Container";
import ContentBlock from "@/components/shared/headings/ContentBlock";
import "react-big-calendar/lib/css/react-big-calendar.css";
import CalenderCard from "@/components/shared/cards/CalendarCard";
import {
  ArrowBackIos,
  ArrowForwardIos,
  Circle,
  EventNote,
} from "@mui/icons-material";
import styled from "styled-components";
import getStatusStyle from "@/utils/getStatusStyle";
import Link from "next/link";
import { useGetMeetingSlotsQuery } from "@/api/meetingAPI";
const events = [
  {
    title: "Long only",
    start: new Date(2024, 1, 1, 1, 0),
    end: new Date(2024, 1, 1, 1, 0),
    status: "accept",
    name: "Wali",
  },
  {
    title: " Sales",
    start: new Date(2023, 11, 16, 10, 0),
    end: new Date(2023, 11, 15, 11, 0),
    status: "pending",
    name: "John",
  },
  {
    title: "Sales",
    start: new Date(2023, 11, 17, 10, 0),
    end: new Date(2023, 11, 15, 11, 0),
    name: "Alex",
    status: "me",
  },
  // Add more events as needed
];
const locales = {
  "en-US": enUS,
};
export default function Home() {
  // useGetMeetingSlotsQuery
  const localizer = dateFnsLocalizer({
    format,
    parse,
    startOfWeek,
    getDay,
    locales,
  });

  const [selectedDate, setSelectedDate] = useState(null);

  const handleDateSelect = ({ start, end }) => {
    setSelectedDate(start);
  };

  const handleNavigate = (action) => {
    console.log("Navigate Action:", action);
  };

  const handleSelectSlot = (slotInfo) => {
    console.log("Selected Slot Info:", slotInfo);
  };

  const handleSelectEvent = (event, e) => {
    console.log("Selected Event:", event);
  };

  const handleDoubleClickEvent = (event, e) => {
    console.log("Double Clicked Event:", event);
  };

  const handleKeyPressEvent = (...args) => {
    console.log("Key Pressed Event:", args);
  };

  const handleDrillDown = (date, view) => {
    console.log("Drill Down:", date, view);
  };

  const handleGetDrilldownView = (
    targetDate,
    currentViewName,
    configuredViewNames
  ) => {
    // console.log(
    //   "Get Drilldown View:",
    //   targetDate,
    //   currentViewName,
    //   configuredViewNames
    // );
  };

  const eventStyleGetter = (event, start, end, isSelected) => {
    console.log("Event:", event, start, end, isSelected);
    return {
      style: {
        backgroundColor: "transparent",
      },
    };
  };

  const slotStyleGetter = (date, start, resourceId, isSelected) => {
    console.log("date:", date, start, resourceId, isSelected);
    return {
      style: {
        backgroundColor: "green",
      },
    };
  };
  const slotGroupStyleGetter = (event, start, end, isSelected) => {
    console.log("Event:", event, start, end, isSelected);
    return {
      style: {
        backgroundColor: "pink",
      },
    };
  };
  const dayStyleGetter = (event, start, end, isSelected) => {
    console.log("Event:", event, start, end, isSelected);
    return {
      style: {
        backgroundColor: "brown",
        color: "red",
      },
    };
  };
  const [anchorEl, setAnchorEl] = useState(null);
  const [hoveredEvent, setHoveredEvent] = useState(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
    setHoveredEvent(event);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setHoveredEvent(null);
  };

  const open = Boolean(anchorEl);
  const CustomToolbar = (toolbar) => {
    console.log("Toolbar:", toolbar);

    const goToBack = () => {
      toolbar.onNavigate("PREV");
    };

    const goToNext = () => {
      toolbar.onNavigate("NEXT");
    };

    return (
      <Box
        className="flex align-items-center justify-content-between"
        sx={{
          py: 2,
          px: 2,
          backgroundColor: "var(--light-grey)",
          borderRadius: "10px 10px 0  0",
        }}
      >
        <Box className="flex align-items-center">
          <EventNote className="main-color" sx={{ width: "1.2rem", mr: 1 }} />
          <Typography variant="subtitle2" className="secondary-color fw-500">
            {format(toolbar.date, "d MMMM, yyyy")}
          </Typography>
        </Box>
        <Box className="flex align-items-center">
          <ArrowBackIos onClick={goToBack} sx={{ width: "1.1rem" }} />
          <Typography variant="subtitle1" className=" fw-500" sx={{ px: 4 }}>
            {toolbar.label}
          </Typography>
          <ArrowForwardIos onClick={goToNext} sx={{ width: "1.1rem" }} />
        </Box>
        <Box></Box>
      </Box>
    );
  };
  const CustomEvent = ({ event }) => {
    const [isCardVisible, setCardVisibility] = useState(false);
    // const handleMouseOver = () => {
    //   setCardVisibility(true);
    // };

    // const handleMouseOut = () => {
    //   setCardVisibility(false);
    // };

    return (
      <>
        <Box
          className="flex align-items-center"
          sx={{
            fontSize: "12px",
            marginTop: "5px",
            color: "#000",
            position: "relative",
          }}
          onMouseOver={handleMouseOver}
          onMouseOut={handleMouseOut}
        >
          <Circle
            sx={{ width: "0.9rem", color: getStatusStyle(event.status) }}
          />
          <span className="light-text">{format(event.start, "h:mm a")}</span> -{" "}
          {event.name} - {event.title}
          {/* <Box
            sx={{
              position: "absolute",
              display: isCardVisible ? "block" : "block",
              // top: "100%", // Position it below the triggering element
              left: "50%", // Center it horizontally
              transform: "translateX(-50%)", // Adjust to center it perfectly
              backgroundColor: "#fff", // Adjust the background color as needed
              border: "1px solid #ccc", // Add border for styling
              padding: "16px",
              zIndex: 999, // Ensure it's above other elements
              boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)", // Add a subtle shadow
            }}
          >
            <CalenderCard />
          </Box> */}
        </Box>
      </>
    );
  };
  const slotPropGetter = (date) => {
    const meetingsInSlot = events.filter(
      (event) => event.start <= date && event.end > date
    );

    if (meetingsInSlot.length > 0) {
      return {
        style: {
          backgroundColor: "lightyellow", // Add a background color for slots with meetings
        },
        onClick: () => handleSlotClick(date, meetingsInSlot),
      };
    }

    return {};
  };

  const handleSlotClick = (date, meetings) => {
    console.log(`Clicked on slot at ${format(date, "h:mm a")}`);
    console.log("Meetings in this slot:", meetings);
    // You can perform any additional actions when a slot is clicked
  };

  const ColoredDateCellWrapper = ({ children }) =>
    React.cloneElement(React.Children.only(children), {
      style: {
        backgroundColor: "green",
      },
    });
  const MyWeekEvent = ({ children, ...props }) => (
    // Implement MyWeekEvent with desired functionality
    <div {...props}>{children}</div>
  );

  const MyMonthHeader = ({ children, ...props }) => (
    // Implement MyMonthHeader with desired functionality
    <div {...props}>{children}</div>
  );

  const MyMonthDateHeader = ({ children, ...props }) => (
    // Implement MyMonthDateHeader with desired functionality
    <div {...props}>{children}</div>
  );

  const MyMonthEvent = ({ children, ...props }) => (
    // Implement MyMonthEvent with desired functionality
    <div {...props}>{children}</div>
  );

  const handleMouseOver = (event, e) => {
    setHoveredEvent(event);
  };

  const handleMouseOut = () => {
    setHoveredEvent(null);
  };
  const CustomTooltip = ({ event }) => (
    <div className="custom-tooltip">
      <strong>{event.title}</strong>
      <p>
        {/* {event.start.toLocaleString()} - {event.end.toLocaleString()} */}
      </p>
      {/* Your custom component content goes here */}
      <div>Custom Component Content</div>
    </div>
  );
  return (
    <>
      <Container>
        <Box sx={{ py: 3 }}>
          <Box
            sx={{ pb: 3 }}
            className="flex align-items-center justify-content-between"
          >
            <ContentBlock
              title="Schedule Practice Interviews"
              description="Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et quasi iusto modi velit ut non voluptas in"
            />

            <Link href="/dashboard/create-meeting">
              <Button variant="contained" color="primary">
                Create Meeting
              </Button>
            </Link>
          </Box>
          <Box sx={{ pt: 1 }}>
            <CalendarStyled>
              <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                endAccessor="end"
                style={{ height: 600 }}
                eventPropGetter={eventStyleGetter}
                slotPropGetter={slotStyleGetter}
                slotGroupPropGetter={slotGroupStyleGetter}
                // dayPropGetter={dayStyleGetter}
                // onSelectEvent={(event, e) => handleSelectEvent(event, e)}
                // onSelectSlot={(slotInfo) => handleSelectSlot(slotInfo)}
                onSelectEvent={(event, e) => handleMouseOver(event, e)}
                onSelectSlot={handleMouseOut}
                onNavigate={(action) => handleNavigate(action)}
                onView={(action) => console.log(action, "actionsssss")}
                onDoubleClickEvent={(event, e) =>
                  handleDoubleClickEvent(event, e)
                }
                onKeyPressEvent={(...args) => handleKeyPressEvent(...args)}
                onDrillDown={(date, view) => handleDrillDown(date, view)}
                getDrilldownView={(
                  targetDate,
                  currentViewName,
                  configuredViewNames
                ) =>
                  handleGetDrilldownView(
                    targetDate,
                    currentViewName,
                    configuredViewNames
                  )
                }
                views={["month", "week", "day"]}
                // step={60}
                // timeslots={2}
                defaultDate={new Date()}
                popup
                // tooltipAccessor={(event) => tooltipAccessor(event)}
                // selectable
                // showMultiDayTimes
                // longPressThreshold={1000}
                // min={new Date(2023, 10, 1)}
                // max={new Date(2023, 10, 30)}
                // scrollToTime={new Date(2023, 10, 15, 8, 0)}
                // width={100000000000000}
                // accessors={{
                //   title: "customTitle",
                //   start: "customStart",
                //   end: "customEnd",
                // }}
                components={{
                  toolbar: CustomToolbar,
                  event: CustomEvent,
                  month: {
                    // header: MyMonthHeader,
                    // dateHeader: MyMonthDateHeader, // Use the updated MyMonthDateHeader component
                    // event: MyMonthEvent,
                  },
                }}
                getters={{
                  dayProp: (date) => {
                    // Customize day properties here
                    return {};
                  },
                }}
                selected={false}
              />
              {hoveredEvent && (
                <>
                  <Box
                    sx={{
                      position: "absolute",
                      top: "20%",
                      left: "50%",
                      transform: "translateX(-50%)",
                      zIndex: 999,
                    }}
                  >
                    <CalenderCard />
                  </Box>
                  {/* <CustomTooltip event={hoveredEvent} /> */}
                </>
              )}

              {/* {selectedDate && (
                <div className="custom-card">
                  <h3>{format(selectedDate, "MMMM d, yyyy")}</h3>
                </div>
              )} */}
            </CalendarStyled>
          </Box>
        </Box>
      </Container>
    </>
  );
}

const CalendarStyled = styled.section`
  position: relative;
  .rbc-off-range-bg {
    background: transparent !important;
  }
  .rbc-today {
    background: transparent !important;
  }
  .rbc-header {
    border-bottom: 0;
    span {
      padding-top: 0.5rem;
      color: var(--secondary-color);
      display: inline-block;
    }
  }
  .rbc-date-cell {
    padding-top: 1rem !important;
    text-align: center;
    span {
      color: #808080;
    }
  }
`;
