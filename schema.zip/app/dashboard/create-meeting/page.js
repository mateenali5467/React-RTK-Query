"use client";
import React from "react";
import {
  Box,
  Typography,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormHelperText,
  Chip,
} from "@mui/material";
import { useFormik } from "formik";
import { createMeetingSchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import { InfoOutlined } from "@mui/icons-material";
import { useCreateMeetingMutation } from "@/api/meetingAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import useToast from "@/hooks/useToast";
import { useSelector } from "react-redux";
const interestsOptions = [
  "Music",
  "Sports",
  "Movies",
  "Technology",
  "Books",
  "Travel",
];

const CreateMeeting = () => {
  const { showToast } = useToast();
  const { user } = useSelector((state) => state.auth);
  const selectedInterests = user.interests
    .filter((item) => item.selected)
    .map((item) => item.label);
  const [createMeeting, { isLoading, error, isError }] =
    useCreateMeetingMutation();
  const formik = useFormik({
    initialValues: {
      title: "",
      meetingDate: "",
      startTime: "",
      interests: [],
      description: "",
    },
    validationSchema: createMeetingSchema,
    onSubmit: async (values, { resetForm }) => {
      // Handle form submission
      try {
        const res = await createMeeting(values);
        showToast("Meeting created successfully");
        // resetForm();
      } catch (error) {
        console.log(error);
        showToast("error", "Something went wrong");
      }
    },
  });
  console.log(formik, "formik");
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Box sx={{ px: 2 }}>
        <Box
          sx={{
            background: "var(--light-grey)",
            py: 5,
            px: { xs: 3, md: 10 },
            maxWidth: "55rem",
            margin: "0 auto",
            my: 5,
            borderRadius: "20px",
          }}
        >
          <Typography variant="h5" className="fw-500">
            Create Meeting
          </Typography>
          <Typography
            variant="subtitle2"
            className="secondary-color"
            sx={{ py: 2 }}
          >
            Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et
            quasi iusto modi velit ut non voluptas in
          </Typography>
          <Box
            sx={{
              input: {
                background: "#fff",
                borderRadius: "11px",
              },
            }}
          >
            <form onSubmit={formik.handleSubmit}>
              <Box sx={{ pb: 3 }}>
                <InputLabel
                  sx={{ py: 0.5, color: "#49454F" }}
                  className="fw-500"
                >
                  Title
                </InputLabel>
                <Input
                  fullWidth
                  name="title"
                  value={formik.values.title}
                  onChange={formik.handleChange}
                  error={formik.touched.title && Boolean(formik.errors.title)}
                  helperText={formik.touched.title && formik.errors.title}
                  placeholder="Enter title here"
                />
              </Box>
              <Box sx={{ pb: 3 }}>
                <InputLabel
                  sx={{ py: 0.5, color: "#49454F" }}
                  className="fw-500"
                >
                  Select Date
                </InputLabel>
                <Input
                  fullWidth
                  name="meetingDate"
                  type="date"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  value={formik.values.meetingDate}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.meetingDate &&
                    Boolean(formik.errors.meetingDate)
                  }
                  helperText={
                    formik.touched.meetingDate && formik.errors.meetingDate
                  }
                  //   placeholder="DD/MM/YYYY"
                />
              </Box>
              <Box sx={{ pb: 3 }}>
                <InputLabel
                  sx={{ py: 0.5, color: "#49454F" }}
                  className="fw-500"
                >
                  Start Time
                </InputLabel>
                <Input
                  fullWidth
                  id="startTime"
                  name="startTime"
                  type="time"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  value={formik.values.startTime}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.startTime && Boolean(formik.errors.startTime)
                  }
                  helperText={
                    formik.touched.startTime && formik.errors.startTime
                  }
                  //   InputProps={{
                  //     // Change the color here
                  //     endAdornment: <AccessTime style={{ color: "red" }} />,
                  //   }}
                />
                <Box sx={{ pt: 1 }} className="flex align-items-center ">
                  <InfoOutlined className="main-color" />
                  <Typography
                    variant="subtitle2"
                    sx={{ color: "#ababab", pl: 1.5 }}
                  >
                    The meeting will be of 90 min
                  </Typography>
                </Box>
              </Box>
              <Box sx={{ pb: 3 }}>
                {/* error */}
                <FormControl fullWidth>
                  {/* <InputLabel
                    id="interests-label"
                    sx={{
                      top: -3,
                    }}
                  >
                    Interests
                  </InputLabel> */}
                  <Select
                    labelId="interests-label"
                    id="interests"
                    name="interests"
                    multiple
                    value={formik.values.interests}
                    onChange={formik.handleChange}
                    renderValue={(selected) => {
                      if (selected.length === 0) {
                        return <p className="color-secondary">Your Interest</p>;
                      }

                      return (
                        <Box
                          sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}
                        >
                          {selected.map((value) => (
                            <Chip
                              key={value}
                              label={value}
                              className="main-color fw-500"
                              sx={{ background: "#2480F926" }}
                            />
                          ))}
                        </Box>
                      );
                    }}
                    displayEmpty
                    sx={{
                      borderRadius: "12px",
                      "& .MuiOutlinedInput-input": {
                        padding: "13px 16px",
                        background: "#fff",
                      },
                    }}
                  >
                    {selectedInterests.map((interest) => (
                      <MenuItem key={interest} value={interest}>
                        <Checkbox
                          checked={formik.values.interests.includes(interest)}
                        />
                        {interest}
                      </MenuItem>
                    ))}
                  </Select>
                  {formik.touched.interests &&
                    Boolean(formik.errors.interests) && (
                      <FormHelperText error>
                        {formik.errors.interests}
                      </FormHelperText>
                    )}
                </FormControl>
              </Box>
              <Box sx={{ pb: 3 }}>
                <InputLabel
                  sx={{ py: 0.5, color: "#49454F" }}
                  className="fw-500"
                >
                  Description
                </InputLabel>
                <Input
                  fullWidth
                  id="description"
                  name="description"
                  placeholder="Add description here"
                  multiline
                  rows={4}
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  error={
                    formik.touched.description &&
                    Boolean(formik.errors.description)
                  }
                  helperText={
                    formik.touched.description && formik.errors.description
                  }
                />
              </Box>
              <Box className="flex justify-content-end">
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  sx={{ py: 1.2 }}
                >
                  Create Meeting
                </Button>
              </Box>
            </form>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default CreateMeeting;
