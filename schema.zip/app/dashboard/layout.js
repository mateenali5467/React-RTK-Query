import React from "react";
import Navbar from "@/components/shared/navbar/DashboardNavbar";
import RequireAuth from "@/components/shared/auth/RequireAuth";
const Layout = ({ children }) => {
  return (
    <>
      <Navbar />
      <RequireAuth>{children}</RequireAuth>
    </>
  );
};

export default Layout;
