"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  FormControl,
  Grid,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import ContentBlock from "@/components/shared/headings/ContentBlock";
import Container from "@/components/layouts/Container";
import { Circle, FilterAltOutlined } from "@mui/icons-material";
import MeetingCard from "@/components/shared/cards/MeetingCard";
import { useSelector } from "react-redux";
import { useGetMeetingQuery } from "@/api/meetingAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
const arr = ["", "", "", ""];

const Interview = () => {
  const { user } = useSelector((state) => state.auth);
  const [filter, setFilter] = React.useState(4);
  const {
    data: meetings,
    isLoading,
    isSuccess,
    isError,
    error,
    refetch,
  } = useGetMeetingQuery(user._id, filter);
  // useEffect(() => {
  //   refetch();
  // }, []);
  console.log(meetings, "meetings");
  const handleChange = (event) => {
    setFilter(event.target.value);
  };

  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Box sx={{ py: 2 }}>
        <Container>
          <ContentBlock
            title="My upcoming meetings"
            description="Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et quasi iusto modi velit ut non voluptas in"
          />

          <Box>
            <Box sx={{ maxWidth: "12rem", py: 5 }}>
              <Select
                value={filter}
                onChange={handleChange}
                displayEmpty
                inputProps={{ "aria-label": "Without label" }}
                fullWidth
                sx={{
                  borderRadius: "11px",
                  "& .MuiSelect-select": {
                    padding: "12px 12px",
                  },
                }}
              >
                <MenuItem value={4}>
                  <Box className="flex align-items-center">
                    <FilterAltOutlined className="main-color" />
                    <Typography variant="h6" className="fw-bold">
                      All Meetings
                    </Typography>
                  </Box>
                </MenuItem>
                <MenuItem value={10}>
                  <Box
                    className="flex justify-content-between"
                    sx={{ width: "100%" }}
                  >
                    <span>Accepted by Me</span>
                    <Circle
                      sx={{ color: "var(--main-color)", width: "0.8rem" }}
                    />
                  </Box>
                </MenuItem>
                <MenuItem value={20}>
                  <Box
                    className="flex justify-content-between"
                    sx={{ width: "100%" }}
                  >
                    <span> Pending Meetings </span>
                    <Circle sx={{ color: "#F6871A", width: "0.8rem" }} />
                  </Box>
                </MenuItem>
                <MenuItem value={30}>
                  <Box
                    className="flex justify-content-between"
                    sx={{ width: "100%" }}
                  >
                    <span> Accepted Meetings </span>
                    <Circle sx={{ color: "#41BE66", width: "0.8rem" }} />
                  </Box>
                </MenuItem>
              </Select>
            </Box>
            <Grid container spacing={2}>
              {meetings &&
                meetings.data &&
                meetings.data.map((meeting, i) => (
                  <Grid item xs={12} md={6} lg={4} key={i}>
                    <MeetingCard meeting={meeting} />
                  </Grid>
                ))}
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};

export default Interview;
