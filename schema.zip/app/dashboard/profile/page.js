"use client";

import React, { useRef, useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Typography,
  Grid,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  InputLabel,
  MenuItem,
  Chip,
  Pagination,
  PaginationItem,
  TextField,
  FormHelperText,
} from "@mui/material";
import Image from "next/image";
import { Edit, GetApp } from "@mui/icons-material";
import DialogBox from "@/components/shared/dialog";
import { useFormik } from "formik";
import { profileSchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import { useDispatch, useSelector } from "react-redux";
import { useUpdateUserMutation } from "@/api/userAPI";
import { AutocompleteStyled } from "@/styles/styled-components/AutoComplete";
import { MenuStyled } from "@/styles/styled-components/Menu";
import { setCredentials } from "@/redux/slices/auth/authSlice";
import { useRouter } from "next/navigation";
import {
  useDeleteCardMutation,
  useGetCardQuery,
  useGetInvoicesQuery,
} from "@/api/paymentAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import { plansData } from "@/data";

const Profile = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const { user, token } = useSelector((state) => state.auth);
  const fileInputRef = useRef(null);
  console.log(user, "auth");
  const selectedInterests = user.interests
    .filter((item) => item.selected)
    .map((item) => item.label);
  const selectedLanguages = user.languages.filter((item) => item.selected);
  const { data: invoices, isLoading: isInvoiceLoading } = useGetInvoicesQuery(
    user._id
  );
  const {
    data: cardDetail,
    isLoading: isCardLoading,
    error: cardDetailError,
  } = useGetCardQuery();
  const [updateUser, { isLoading, isError, error, isSuccess }] =
    useUpdateUserMutation();
  const [deleteCard, { isLoading: isCardDeleteLoading }] =
    useDeleteCardMutation();
  console.log(cardDetail, "invoices");
  console.log(cardDetailError, "invoices cardDetailError");
  const [isModal, setIsModal] = useState(false);
  const [submittedValues, setSubmittedValues] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  console.log(imagePreview, "imagePreview");

  const handleFileChange = (event) => {
    const file = event.currentTarget.files[0];
    formik.setFieldValue("image", file);

    // Display image preview
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };
  const formik = useFormik({
    initialValues: {
      image: user.image || null,
      name: user.name || "",
      interests: selectedInterests || [],
      languages: selectedLanguages || [],
      plan: "",
    },
    validationSchema: profileSchema,
    enableReinitialize: true,
    onSubmit: async (values) => {
      // Handle submission logic here
      // console.log(values.image);
      // return;
      const countryNames = values.languages.map((item) => item.label);
      const data = { ...values, languages: countryNames };
      if (imagePreview) {
        data.image = imagePreview;
      }
      try {
        const res = await updateUser({ userId: user._id, updatedUser: data });
        dispatch(setCredentials({ user: res.data.data, token }));
        setIsModal(false);
        console.log(res, "res");
      } catch (error) {
        console.log(error);
      }
      // console.log(data, "countryNames");
      // Store the submitted values
      // setSubmittedValues(values);
      // Close the modal
      // setIsModal(false);
      // Additional logic if needed after form submission
    },
  });
  // console.log(country, "country");
  console.log(formik.values, "formik");
  const downloadInvoice = (invoice) => {
    // Create a temporary link element
    const link = document.createElement("a");
    link.href = invoice;
    link.target = "_blank"; // Open the link in a new tab/window
    link.download = "invoice.pdf"; // Set the desired file name

    // Append the link to the document
    document.body.appendChild(link);

    // Trigger a click on the link to start the download
    link.click();

    // Remove the link from the document
    document.body.removeChild(link);
  };

  const removeCard = async () => {
    try {
      const res = await deleteCard(cardDetail?.data?.cardId).unwrap();
      dispatch(setCredentials({ user: { ...user, customerId: null }, token }));
      showToast("Card removed successfully");
      refetch();
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      {/* <ReactFlagsSelect
        selected={country}
        onSelect={(code) => setCountry(code)}
        fullWidth={false}
        className="flag"
      /> */}
      {(isInvoiceLoading || isCardDeleteLoading || isCardLoading) && <FullScreenLoader />}
      <Box sx={{ px: 2 }}>
        <Box
          sx={{
            maxWidth: "70rem",
            margin: "0 auto",
            my: 5,
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} lg={8}>
              <Box
                className="flex align-items-center"
                sx={{ flexDirection: { xs: "column", md: "row" } }}
              >
                <Box
                  sx={{
                    pr: 3,
                    img: {
                      borderRadius: "50%",
                    },
                  }}
                >
                  <Image
                    src={
                      user.image ? user.image : "/assets/images/user-avator.png"
                    }
                    width={120}
                    height={120}
                    alt="avatar"
                  />
                </Box>
                <Box sx={{ width: "100%" }}>
                  <Box className="flex align-items-center">
                    <Typography
                      variant="h5"
                      className="fw-500"
                      sx={{ py: 0.8 }}
                    >
                      {user?.name}
                    </Typography>
                    <Box
                      sx={{
                        cursor: "pointer",
                        pl:2,
                        "&:hover": {
                          opacity: 0.8,
                        },
                      }}
                      onClick={() => setIsModal(true)}
                    >
                      <Image
                        src="/assets/svg/edit.svg"
                        width={20}
                        height={20}
                      />
                    </Box>
                  </Box>

                  <Typography
                    variant="subtitle2"
                    className="fw-500 secondary-color"
                    sx={{
                      py: 0.8,
                      "& .interest": {
                        color: "#ABABAB",
                      },
                    }}
                  >
                    Interests:{" "}
                    <span className="interest">
                      {user?.interests
                        .filter((item) => item.selected)
                        .map((item, index, array) => (
                          <React.Fragment key={index}>
                            {item.label}
                            {index < array.length - 1 && ", "}
                          </React.Fragment>
                        ))}
                    </span>
                  </Typography>
                  <Typography
                    variant="subtitle2"
                    className="fw-500 secondary-color"
                    sx={{
                      py: 0.8,
                      "& .interest": {
                        color: "#ABABAB",
                      },
                    }}
                  >
                    Languages:{" "}
                    <span className="interest">
                      {user?.languages
                        .filter((item) => item.selected)
                        .map((item, index, array) => (
                          <React.Fragment key={index}>
                            {item.label}
                            {index < array.length - 1 && ", "}
                          </React.Fragment>
                        ))}
                    </span>
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} lg={4}>
              {/* <Box
                className="flex justify-content-end align-items-center"
                sx={{
                  cursor: "pointer",
                  "&:hover": {
                    opacity: 0.8,
                  },
                }}
                onClick={() => setIsModal(true)}
              >
                <Button
                  sx={{ mb: 2, background: "var(--main-color)" }}
                  variant="contained"
                  className=""
                >
                  Edit Profile
                </Button>
              </Box> */}
              {cardDetail?.data && (
                <Box
                  sx={{
                    border: "1px solid var(--border-color)",
                    borderRadius: "20px",
                    pt: 2,
                  }}
                >
                  <Box sx={{ px: 2 }}>
                    <Box className="flex justify-content-between align-items-center">
                      <Typography
                        variant="h6"
                        className="fw-500 secondary-color"
                      >
                        {cardDetail?.data?.name}
                      </Typography>
                      <Image
                        src={
                          cardDetail?.data?.cardType === "Visa"
                            ? "/assets/svg/visa.svg"
                            : "/assets/svg/master_card.svg"
                        }
                        width={40}
                        height={40}
                        alt="card icon"
                      />
                    </Box>
                    <Box
                      className="flex justify-content-between align-items-center"
                      sx={{ py: 2 }}
                    >
                      <Typography
                        variant="h6"
                        className="fw-500 secondary-color"
                      >
                        {cardDetail?.data?.formattedCardNumber}
                      </Typography>
                      <Typography variant="h6" className="secondary-color">
                        {`${cardDetail?.data?.expMonth}/${cardDetail?.data?.expYear}`}
                      </Typography>
                    </Box>
                  </Box>

                  <Box
                    sx={{
                      cursor: "pointer",
                      "&:hover": {
                        opacity: 0.8,
                      },
                    }}
                    onClick={removeCard}
                  >
                    <Typography
                      variant="caption"
                      className="fw-500 secondary-color text-center d-block"
                      sx={{ borderTop: "1px solid var(--border-color)", py: 1.5 }}
                    >
                      Remove card
                    </Typography>
                  </Box>
                </Box>
              )}
            </Grid>
          </Grid>
          <Box sx={{ py: 3 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={8}>
                <Tabs
                  value="one"
                  aria-label="wrapped label tabs example"
                  sx={{
                    "& .Mui-selected": {
                      color: "var(--main-color) !important",
                      fontWeight: "bold",
                    },
                    "& .MuiTabs-indicator": {
                      backgroundColor: "var(--main-color)",
                    },
                  }}
                >
                  <Tab value="one" label="Payment History" wrapped />
                </Tabs>
              </Grid>
              <Grid item xs={12} lg={4}>
                <Box className="box" sx={{ p: 3, position: "relative" }}>
                  <Typography
                    variant="subtitle2"
                    className="light-text"
                    sx={{ pb: 1 }}
                  >
                    Current Subscription
                  </Typography>
                  <Typography variant="h6" className="fw-500 secondary-color">
                    {
                      plansData.find(
                        (plan) => plan.id === user.subscriptionPlan
                      )?.type
                    }
                    <span className="light-text" style={{ fontSize: "14px" }}>
                      {" "}
                      $
                      {
                        plansData.find(
                          (plan) => plan.id === user.subscriptionPlan
                        )?.price
                      }
                      /months
                    </span>
                  </Typography>
                  <Box>
                    <IconButton
                      aria-label="edit"
                      onClick={() =>
                        router.push(
                          `/finterview/payment/plan?plan=${user.subscriptionPlan}`
                        )
                      }
                      sx={{
                        position: "absolute",
                        right: "18px",
                        top: "12px",
                        width: "2rem",
                        height: "2rem",
                        "&:hover": {
                          opacity: 0.8,
                        },
                      }}
                    >
                      <Image
                        src="/assets/svg/edit.svg"
                        width={20}
                        height={20}
                      />
                    </IconButton>
                  </Box>
                </Box>
              </Grid>
            </Grid>

            <TableContainer
              sx={{
                py: 3,
                "& .MuiTableCell-root": {
                  color: "#ABABAB",
                  borderBottom: "none",
                },
              }}
            >
              <Table
                sx={{
                  minWidth: 650,
                  borderCollapse: "separate",
                  borderSpacing: "0 15px",
                }}
                aria-label="simple table"
              >
                <TableHead>
                  <TableRow>
                    <TableCell>Subscription</TableCell>
                    <TableCell align="left">Date</TableCell>
                    <TableCell align="left">Amount</TableCell>
                    <TableCell align="left">Invoice Number</TableCell>
                    <TableCell align="left"></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody
                  sx={{
                    th: {
                      color: "var(--secondary-color) !important",
                      fontWeight: "bold",
                    },
                    "& .MuiTableRow-root th:first-child": {
                      borderTopLeftRadius: "10px",
                      borderBottomLeftRadius: "10px",
                    },
                    "& .MuiTableRow-root th:last-child": {
                      borderTopRightRadius: "10px",
                      borderBottomRightRadius: "10px",
                    },
                  }}
                >
                  {invoices &&
                    invoices.data &&
                    invoices.data.map((row, index) => (
                      <TableRow
                        key={index}
                        sx={{
                          "td, th": { border: 0 },
                          background: "#F7F7F7",
                        }}
                      >
                        <TableCell component="th" scope="row">
                          {
                            plansData.find(
                              (plan) => plan.id === row.subscriptionPlan
                            )?.type
                          }
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {row.date}
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {`$ ${row.amountPaid}`}
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {row.invoiceNumber}
                        </TableCell>
                        <TableCell component="th" scope="row">
                          <IconButton aria-label="download">
                            <GetApp
                              sx={{
                                color: "var(--main-color)",
                              }}
                              onClick={() => downloadInvoice(row.invoice_pdf)}
                            />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
            {/* <Box
              sx={{
                pt: 1,
                display: "flex",
                justifyContent: "space-between",
                alignItems: { xs: "flex-start", md: "center" },
                flexDirection: { xs: "column", md: "row" },
              }}
            >
              <Box sx={{ pb: 1.5 }}>
                <Typography variant="subtitle2" className="light-text">
                  Showing 1 - 3 of 3
                </Typography>
              </Box>
              <Pagination
                count={1}
                shape="rounded"
                // renderItem={(item) => (
                //   <PaginationItem
                //     component={(props) => {
                //       if (item.type === "previous") {
                //         return <Delete {...props} />;
                //       } else if (item.type === "next") {
                //         return <ArrowForward {...props} />;
                //       }
                //       return <PaginationItem {...props} />;
                //     }}
                //     {...item}
                //   />
                // )}
                sx={{
                  "& .Mui-selected": {
                    backgroundColor: "var(--main-color) !important",
                    color: "#fff",
                  },
                }}
              />
            </Box> */}
          </Box>
        </Box>
      </Box>
      {isModal && (
        <DialogBox>
          {/* <DialogBox sx={{ width: { xs: "100%", md: "28rem" } }}> */}
          <form onSubmit={formik.handleSubmit} style={{ width: "30rem" }}>
            <Box
              sx={{ py: 1, height: "9rem" }}
              className="flex justify-content-center"
            >
              <input
                accept="image/jpeg, image/png"
                id="image"
                type="file"
                style={{ display: "none" }}
                ref={fileInputRef}
                onChange={handleFileChange}
              />

              {formik.errors.image && formik.touched.image && (
                <div style={{ color: "red" }}>{formik.errors.image}</div>
              )}
              <Box
                sx={{
                  position: "relative",
                  width: "fit-content",
                  img: {
                    objectFit: "cover",
                    borderRadius: "50%",
                  },
                }}
              >
                <IconButton
                  aria-label="edit"
                  onClick={() => fileInputRef.current.click()}
                  sx={{
                    position: "absolute",
                    color: "#fff",
                    right: 0,
                    bottom: "7px",
                    width: "2rem",
                    height: "2rem",
                    "&:hover": {
                      opacity: 0.8,
                    },
                  }}
                >
                  <Image src="/assets/svg/camera.svg" width={30} height={30} />
                </IconButton>
                <Box
                  sx={{
                    width: "7rem",
                    height: "8rem",
                  }}
                >
                  {imagePreview ? (
                    <Image
                      src={imagePreview}
                      alt="Image Preview"
                      width={120}
                      height={120}
                    />
                  ) : formik.values.image ? (
                    <Image
                      src={formik.values.image}
                      alt="Image Preview"
                      width={120}
                      height={120}
                    />
                  ) : (
                    <Image
                      src="/assets/images/user-avator.png"
                      width={120}
                      height={120}
                      alt="avatar"
                    />
                  )}
                </Box>
              </Box>
            </Box>
            <Box sx={{ py: 1 }}>
              <InputLabel sx={{ fontWeight: "bold" }}>Name</InputLabel>
              <Input
                fullWidth
                id="name"
                name="name"
                placeholder="Name"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.name}
                error={formik.touched.name && Boolean(formik.errors.name)}
                helperText={formik.touched.name && formik.errors.name}
              />
            </Box>
            <Box sx={{ py: 1 }}>
              <InputLabel sx={{ fontWeight: "bold" }}>Interests</InputLabel>
              <MenuStyled
                fullWidth
                id="interests"
                name="interests"
                multiple
                displayEmpty
                inputProps={{ "aria-label": "Without label" }}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.interests}
                error={
                  formik.touched.interests && Boolean(formik.errors.interests)
                }
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return <p className="color-secondary">Your Interest</p>;
                  }
                  return (
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip
                          key={value}
                          label={value}
                          className="main-color fw-500"
                          sx={{ background: "#2480F926" }}
                          onMouseDown={(event) => event.stopPropagation()}
                          onDelete={(event) => {
                            event.stopPropagation();
                            // Handle delete action here
                            const updatedInterests =
                              formik.values.interests.filter(
                                (interest) => interest !== value
                              );
                            formik.setFieldValue("interests", updatedInterests);
                          }}
                        />
                      ))}
                    </Box>
                  );
                }}
              >
                {user.interests.map((option) => (
                  <MenuItem key={option.label} value={option.label}>
                    {option.label}
                  </MenuItem>
                ))}
              </MenuStyled>

              {formik.touched.interests && Boolean(formik.errors.interests) && (
                <FormHelperText sx={{ color: "var(--error-color)", pl: 2 }}>
                  {formik.errors.interests}
                </FormHelperText>
              )}
            </Box>
            <Box sx={{ py: 1 }}>
              <InputLabel htmlFor="languages" sx={{ fontWeight: "bold" }}>
                Languages
              </InputLabel>
              <AutocompleteStyled
                id="languages"
                name="languages"
                multiple
                onChange={(_, values) => {
                  formik.setFieldValue("languages", values);
                }}
                onBlur={formik.handleBlur}
                value={formik.values.languages}
                options={user.languages}
                renderOption={(props, option) => (
                  <li {...props}>
                    <Checkbox
                      checked={formik.values.languages.some(
                        (lang) => lang.value === option.value
                      )}
                    />
                    <img
                      alt={option.label}
                      src={`https://img.mobiscroll.com/demos/flags/${option.value}.png`}
                      style={{
                        maxWidth: "2rem",
                        marginRight: "12px",
                      }}
                    />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    // label="Select Multiple Values"
                    error={
                      formik.touched.languages &&
                      Boolean(formik.errors.languages)
                    }
                    helperText={
                      formik.touched.languages && formik.errors.languages
                    }
                    placeholder={
                      formik.touched.languages && formik.errors.languages
                        ? formik.errors.languages
                        : formik.values.languages.length === 0
                        ? "Select Languages"
                        : ""
                    }
                    // placeholder="Languages"
                  />
                )}
              />
            </Box>
            {/* <Box sx={{ py: 1 }}>
              <InputLabel htmlFor="plan" sx={{ fontWeight: "bold" }}>
                Plan
              </InputLabel>
              <Select
                fullWidth
                id="plan"
                name="plan"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.plan}
                error={formik.touched.plan && Boolean(formik.errors.plan)}
              >
                {PlanOptions.map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
              {formik.touched.plan && Boolean(formik.errors.plan) && (
                <Typography color="error">{formik.errors.plan}</Typography>
              )}
            </Box> */}
            <Box sx={{ pt: 3 }}>
              <Button
                type="submit"
                color="primary"
                variant="contained"
                className="normal-text"
              >
                {isLoading ? "Submitting" : "Submit"}
              </Button>
              <Button
                color="primary"
                variant="contained"
                sx={{ ml: 2 }}
                onClick={() => setIsModal(false)}
                className="normal-text"
              >
                Close
              </Button>
            </Box>
          </form>
        </DialogBox>
      )}
    </>
  );
};

export default Profile;
