"use client";

import React from "react";
import { Box, Button, Grid, Typography } from "@mui/material";
import ContentBlock from "@/components/shared/headings/ContentBlock";
import Container from "@/components/layouts/Container";
import Link from "next/link";
import MeetingCard from "@/components/shared/cards/MeetingCard";
import { useSelector } from "react-redux";
import { useGetPracticeInterviewsQuery } from "@/api/meetingAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import InterviewCard from "@/components/shared/cards/InterviewCard";
const Interview = () => {
  const { user } = useSelector((state) => state.auth);
  const {
    data: interviews,
    isLoading,
    isSuccess,
    isError,
    error,
    refetch,
  } = useGetPracticeInterviewsQuery(user._id);
  console.log(interviews, "interviews");
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const arr = ["", "", "", ""];

  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Box sx={{ py: 2 }}>
        <Container>
          <Box
            sx={{ pb: 3, flexDirection: { xs: "column", md: "row" } }}
            className="flex align-items-center justify-content-between"
          >
            <ContentBlock
              title="Schedule Practice Interviews"
              description="Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et quasi iusto modi velit ut non voluptas in"
            />
            <Link href="/dashboard/create-meeting">
              <Button variant="contained" color="primary">
                Create Meeting
              </Button>
            </Link>
          </Box>
          <Box sx={{ pt: 5 }}>
            <Grid container spacing={2}>
              {interviews &&
                interviews.data &&
                interviews.data.map((item, i) => (
                  <Grid item xs={12} md={6} lg={4} key={i}>
                    <InterviewCard meeting={item} refetch={refetch} />
                  </Grid>
                ))}
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};

export default Interview;
