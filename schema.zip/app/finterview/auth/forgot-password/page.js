"use client";
import React from "react";
import Layout from "@/components/layouts/SharedLayout";
import { Box, Button, InputLabel, Link, Typography } from "@mui/material";
import { useFormik } from "formik";
import { forgotSchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import { useSendEmailMutation } from "@/api/authAPI";
import useToast from "@/hooks/useToast";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
const ForgetPassword = () => {
  const { showToast } = useToast();
  const [sendEmail, { isLoading, isError, error, isSuccess, ...rest }] =
    useSendEmailMutation();
  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validationSchema: forgotSchema,
    onSubmit: async (values) => {
      try {
        const { data } = await sendEmail(values).unwrap();
        showToast("Email sent successfully please check your inbox");
      } catch (error) {
        showToast("Something went wrong please try again later", "error");
      }
    },
  });
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Layout>
        <Box>
          <Typography
            variant="h5"
            className="fw-500 text-center"
            sx={{ pb: 2 }}
          >
            Forgot Password
          </Typography>
          <Typography
            variant="body2"
            className="secondary-color fw-500 text-center"
            sx={{ pb: 5, fontSize: "13px" }}
          >
            Enter your registered email address. You will receive a verification
            code to reset your password
          </Typography>
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{ pb: 4 }}>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Email Address
              </InputLabel>
              <Input
                fullWidth
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
                placeholder="user@exAMple.com"
              />
            </Box>

            <Button
              variant="contained"
              fullWidth
              type="submit"
              sx={{
                background: "var(--main-color)",
                py: 1,
                borderRadius: "8px",
              }}
              className="normal-text"
            >
              Send
            </Button>
            <Typography
              href="/finterview/auth/sign-in"
              variant="body2"
              sx={{ color: "var(--secondary-color)", pt: 2.5 }}
              underline="hover"
              className="fw-500 text-center d-block"
            >
              Back to
              <span className="main-color">
                <Link href="/finterview/auth/sign-in" underline="hover">
                  {" "}
                  Sign in
                </Link>{" "}
              </span>
            </Typography>
          </form>
        </Box>
      </Layout>
    </>
  );
};

export default ForgetPassword;
