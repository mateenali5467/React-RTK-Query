"use client";
import React, { useState, useRef } from "react";
import { Box, Button, TextField, Typography } from "@mui/material";
import useToast from "@/hooks/useToast";
import { useOptVerifiedMutation } from "@/api/userAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import { useRouter } from "next/navigation";
const Pin = ({ params, searchParams }) => {
  const router = useRouter();
  const { showToast } = useToast();

  const [optVerified, { isLoading, isError, error }] = useOptVerifiedMutation();
  const [pins, setPins] = useState(["", "", "", ""]);
  const pinRefs = [useRef(), useRef(), useRef(), useRef()];
  //   if (isError) {
  //     showToast(error.data.message, "error");
  //   }
  const handlePinChange = (index, value) => {
    const newPins = [...pins];
    newPins[index] = value.replace(/\D/g, "").slice(0, 1);
    setPins(newPins);
    // Move focus to the next input field
    if (index < pinRefs.length - 1 && value !== "") {
      pinRefs[index + 1].current.focus();
    }
  };
  const handleSubmit = async () => {
    const pin = pins.join("");
    if (pin.length === 4) {
      onCompleted(pin);
    } else {
      showToast("Please enter a valid 4-digit PIN.", "error");
    }
  };

  const onCompleted = async (pin) => {
    try {
      const res = await optVerified({
        opt: pin,
        email: searchParams.email,
      }).unwrap();
      console.log(res, "res");
      // if (res.data.success) {
      showToast("Registered successfully");
      router.push("/finterview/auth/sign-in");
      // } else {
      //   console.log(res.data.message, "res.data.message");
      //   showToast(res.error.data.message, "error");
      // }
    } catch (error) {
      console.log(error, "error");
      showToast(error.data.message, "error");
    }
  };
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Box sx={{ p: { xs: 4, md: 10 }, textAlign: "center" }}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{
            fontSize: { xs: "1.3rem", md: "2.1rem" },
          }}
        >
          Please check your email and set the PIN.
        </Typography>
        <Typography variant="body1">{`Welcome, ${searchParams.name}!`}</Typography>
        <Box className="flex justify-content-center" sx={{ mt: 3 }}>
          {pins.map((pin, index) => (
            <TextField
              key={index}
              sx={{
                width: "3rem",
                margin: "0 0.5rem",
              }}
              variant="outlined"
              type="text"
              inputProps={{ maxLength: 1 }}
              value={pin}
              onChange={(e) => handlePinChange(index, e.target.value)}
              inputRef={pinRefs[index]}
            />
          ))}
        </Box>
        <Box sx={{ mt: 3 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleSubmit}
            className="normal-text"
          >
            Submit
          </Button>
        </Box>
      </Box>
    </>
  );
};

export default Pin;
