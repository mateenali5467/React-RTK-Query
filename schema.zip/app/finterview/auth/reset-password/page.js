"use client";
import React from "react";
import Layout from "@/components/layouts/SharedLayout";
import { Box, Button, InputLabel, Link, Typography } from "@mui/material";
import { useFormik } from "formik";
import { resetPasswordSchema } from "@/schema";
import PasswordField from "@/components/auth/PasswordField";
import { useResetPasswordMutation } from "@/api/authAPI";
import useToast from "@/hooks/useToast";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import { useSearchParams, useRouter } from "next/navigation";
const ResetPassword = () => {
  const { showToast } = useToast();
  const searchParams = useSearchParams();
  const router = useRouter();

  const token = searchParams.get("token");
  const [resetPassword, { isLoading, isError, error, isSuccess, ...rest }] =
    useResetPasswordMutation();
  const formik = useFormik({
    initialValues: {
      password: "",
      confirmPassword: "",
    },
    validationSchema: resetPasswordSchema,
    onSubmit: async (values) => {
      try {
        const { data } = await resetPassword({ token, ...values }).unwrap();
        showToast("Password reset successfully");
        router.push("/finterview/auth/sign-in");
      } catch (error) {
        showToast("Something went wrong please try again later", "error");
      }
    },
  });
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Layout>
        <Box>
          <Typography
            variant="h5"
            className="fw-500 text-center"
            sx={{ pb: 2 }}
          >
            Reset Password
          </Typography>
          <Typography
            variant="body2"
            className="secondary-color fw-500 text-center"
            sx={{ pb: 5 }}
          >
            Choose new password for your account
          </Typography>
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{ pb: 3 }}>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Password
              </InputLabel>
              <PasswordField
                fullWidth
                name="password"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.password && Boolean(formik.errors.password)
                }
                helperText={formik.touched.password && formik.errors.password}
                placeholder="Enter Password"
              />
            </Box>
            <Box
              sx={{
                pb: 3,
              }}
            >
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Confirm Password
              </InputLabel>
              <PasswordField
                fullWidth
                name="confirmPassword"
                value={formik.values.confirmPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.confirmPassword &&
                  Boolean(formik.errors.confirmPassword)
                }
                helperText={
                  formik.touched.confirmPassword &&
                  formik.errors.confirmPassword
                }
                placeholder="Re-enter your password"
              />
            </Box>

            <Button
              variant="contained"
              fullWidth
              type="submit"
              sx={{
                background: "var(--main-color)",
                py: 1,
                borderRadius: "8px",
              }}
              className="normal-text"
            >
              Submit
            </Button>
            <Typography
              // href="/finterview/auth/sign-in"
              variant="body2"
              sx={{ color: "var(--secondary-color)", pt: 2.5 }}
              className="fw-500 text-center d-block"
            >
              Back to
              <Link href="/finterview/auth/sign-in" underline="hover">
                <span className="main-color"> Sign in</span>
              </Link>
            </Typography>
          </form>
        </Box>
      </Layout>
    </>
  );
};

export default ResetPassword;
