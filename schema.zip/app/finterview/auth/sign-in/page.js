"use client";
import React, { useState } from "react";
import Layout from "@/components/layouts/SharedLayout";
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  InputLabel,
  Link,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import { loginSchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import PasswordField from "@/components/auth/PasswordField";
import SocialLogin from "@/components/auth/SocialLogin";
import DividerChip from "@/components/auth/DividerChip";
// import { useCreateUserMutation } from "@/api/userAPI";
import { useSignInMutation } from "@/api/authAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import useToast from "@/hooks/useToast";
import {
  selectCurrentToken,
  setCredentials,
} from "@/redux/slices/auth/authSlice";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import { useGetUserQuery } from "@/api/userAPI";
const Login = () => {
  const token = useSelector(selectCurrentToken);
  // console.log("token", token);
  const dispatch = useDispatch();
  const router = useRouter();
  const { showToast } = useToast();
  const [signIn, { isLoading, isError, error, isSuccess, ...rest }] =
    useSignInMutation();
  // const [getUser] = useGetUserQuery();
  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: loginSchema,
    onSubmit: async (values) => {
      try {
        const { user, token } = await signIn(values).unwrap();
        console.log("data", user);
        dispatch(setCredentials({ user, token }));
        // Check if all "selected" values are false
        const allSelectedFalse = user.interests.every(
          (interest) => !interest.selected
        );
        // Redirect based on the condition
        if (allSelectedFalse) {
          // Redirect to the interest page
          router.push("/finterview/select-interest");
          showToast("Login successfully");
        } else {
          // You can redirect to another page or dispatch additional actions here
          router.push("/dashboard/profile");
        }
      } catch (error) {
        // console.log("error", error);
        showToast(error.data.message, "error");
        // console.error(":", error);
      }
    },
  });
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Layout>
        <Box>
          <Typography
            variant="h5"
            className="fw-500 text-center"
            sx={{ pb: 4 }}
          >
            Login to Finterview
          </Typography>
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{ pb: 3 }}>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Email Address
              </InputLabel>
              <Input
                fullWidth
                id="email"
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
                placeholder="user@Example.com"
              />
            </Box>
            <Box>
                    <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Password
              </InputLabel>
              <PasswordField
                name="password"
                fullWidth
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.password && Boolean(formik.errors.password)
                }
                helperText={formik.touched.password && formik.errors.password}
              />
            </Box>

            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                flexWrap: "wrap !important",
                py: 1.5,
              }}
            >
              <FormControlLabel
                control={<Checkbox value="remember" color="primary" />}
                label="Remember me"
                sx={{
                  "& .MuiTypography-root": {
                    fontWeight: "500",
                    fontSize: "14px",
                  },
                  "& .MuiButtonBase-root": {
                    paddingRight: "2px",
                  },
                }}
              />
              <Link
                href="/finterview/auth/forgot-password"
                variant="body2"
                underline="hover"
                sx={{ color: "#444444" }}
                className="fw-500"
              >
                Forgot password?
              </Link>
            </Box>

            <Button
              variant="contained"
              fullWidth
              type="submit"
              sx={{
                background: "var(--main-color)",
                py: 1,
                borderRadius: "8px",
              }}
              className="normal-text"
            >
              Login
            </Button>
            <DividerChip title="or login via" />
            <SocialLogin />
            <Typography
              variant="body2"
              sx={{ color: "var(--secondary-color)", pt: 2.5 }}
              underline="hover"
              className="fw-500 text-center d-block"
            >
              Do not have an account?{" "}
              <span className="main-color">
                <Link
                  href="/finterview/auth/sign-up"
                  variant="body2"
                  sx={{ pt: 2.5 }}
                  underline="hover"
                  className="fw-500 text-center main-color"
                >
                  Sign Up
                </Link>
              </span>
            </Typography>
          </form>
        </Box>
      </Layout>
    </>
  );
};

export default Login;
