"use client";
import React, { useState, useEffect } from "react";
import Layout from "@/components/layouts/SharedLayout";
import {
  Box,
  Button,
  Checkbox,
  InputLabel,
  Link,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import { signupSchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import PasswordField from "@/components/auth/PasswordField";
import SocialLogin from "@/components/auth/SocialLogin";
import DividerChip from "@/components/auth/DividerChip";
import { useCreateUserMutation } from "@/api/userAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import useToast from "@/hooks/useToast";
import { useRouter } from "next/navigation";
const Signup = () => {
  const { showToast } = useToast();
  const router = useRouter();
  const [createUser, { isLoading, isError, error, isSuccess, ...rest }] =
    useCreateUserMutation();
  // console.log(rest, "est");
  // console.log(isLoading, "isLoading");
  // console.log(isError, "isError");
  // console.log(error, "error");
  // console.log(isSuccess, "isSuccess");

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      password: "",
      emailPromo: true,
      //   confirmPassword: "",
    },
    validationSchema: signupSchema,
    onSubmit: async (values) => {
      try {
        const { data } = await createUser(values).unwrap();
        // showToast("User registered successfully");
        // You can redirect to another page or dispatch additional actions here
        router.push(
          `/finterview/auth/pin?email=${values.email}&name=${values.name}`
        );
      } catch (error) {
        showToast(error.data.message, "error");
        // console.error(":", error);
      }
    },
  });
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Layout>
        <Box>
          <Typography
            variant="h5"
            className="fw-500 text-center"
            sx={{ pb: 4 }}
          >
            Get started for free
          </Typography>
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{ pb: 3 }}>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Full Name
              </InputLabel>
              <Input
                fullWidth
                name="name"
                value={formik.values.name}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.name && Boolean(formik.errors.name)}
                helperText={formik.touched.name && formik.errors.name}
                placeholder="e.g John Doe"
              />
            </Box>
            <Box sx={{ pb: 3 }}>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Email Address
              </InputLabel>
              <Input
                fullWidth
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
                placeholder="user@exAMple.com"
              />
            </Box>
            <Box>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }} className="fw-500">
                Password
              </InputLabel>
              <PasswordField
                fullWidth
                name="password"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.password && Boolean(formik.errors.password)
                }
                helperText={formik.touched.password && formik.errors.password}
              />
            </Box>
            {/* <Box>
              <InputLabel sx={{ py: 0.5, color: "#49454F" }}>
                Confirm Password
              </InputLabel>
              <PasswordField
                fullWidth
                name="confirmPassword"
                value={formik.values.confirmPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.confirmPassword &&
                  Boolean(formik.errors.confirmPassword)
                }
                helperText={
                  formik.touched.confirmPassword &&
                  formik.errors.confirmPassword
                }
              />
            </Box> */}
            <Box
              sx={{
                py: 1.5,
              }}
            >
              <Typography variant="body2" className="fw-500">
                By creating an account you are agreeing the Terms of use and
                Privacy Policy
              </Typography>
            </Box>

            <Button
              variant="contained"
              fullWidth
              type="submit"
              sx={{
                background: "var(--main-color)",
                py: 1,
                borderRadius: "8px",
                textTransform: "none",
              }}
            >
              Sign up
            </Button>
            <DividerChip title="or login via" />
            <SocialLogin />
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                pt: 2.5,
              }}
            >
              <Typography
                variant="body2"
                className="fw-500 text-center secondary-color"
              >
                Receive promo emails
              </Typography>
              <Box sx={{ pl: 1 }}>
                <Checkbox
                  name="emailPromo"
                  checked={formik.values.emailPromo}
                  onChange={formik.handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              </Box>
            </Box>
            <Typography
              // href="/finterview/auth/sign-in"
              variant="body2"
              sx={{ color: "var(--secondary-color)", pt: 2.5 }}
              underline="hover"
              className="fw-500 text-center d-block"
            >
              Already have an account?{" "}
              <span className="main-color">
                <Link
                  href="/finterview/auth/sign-in"
                  variant="body2"
                  sx={{ pt: 2.5 }}
                  underline="hover"
                  className="fw-500 text-center main-color"
                >
                  Sign in
                </Link>
              </span>
            </Typography>
          </form>
        </Box>
      </Layout>
    </>
  );
};

export default Signup;
