import React from "react";
import Navbar from "@/components/shared/navbar/DefaultNavbar";
const Layout = ({ children }) => {
  return (
    <>
      <Navbar />
      {children}
    </>
  );
};

export default Layout;
