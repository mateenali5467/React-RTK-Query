"use client";

import React, { useState, useEffect } from "react";
import { paySchema } from "@/schema";
import { Input } from "@/styles/styled-components/Input";
import { useFormik } from "formik";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import { formatCardNumber, formatExpiryDate } from "@/utils/formatting";
import { plansData } from "@/data";
import PlanCard from "@/components/shared/cards/PlanCard";
import { useSearchParams } from "next/navigation";
import SharedLayout from "@/components/layouts/SharedLayout";
import { CalendarToday, CreditCard } from "@mui/icons-material";
import { useAddCardMutation } from "@/api/paymentAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import { useDispatch, useSelector } from "react-redux";
import useToast from "@/hooks/useToast";
import { useRouter } from "next/navigation";
import { setCredentials } from "@/redux/slices/auth/authSlice";
import Image from "next/image";
const Pay = () => {
  const searchParams = useSearchParams();
  const { showToast } = useToast();
  const router = useRouter();
  const dispatch = useDispatch();
  const { user, token } = useSelector((state) => state.auth);
  const type = searchParams.get("plan");
  const [selectedPlan, setSelectedPlan] = useState({});
  const [addCard, { isLoading }] = useAddCardMutation();
  useEffect(() => {
    if (!type) return;
    // Find the plan based on the type
    const selectedPlan = plansData.find((plan) => plan.type === type);
    setSelectedPlan(selectedPlan);
  }, [type]);

  // console.log(selectedPlan, "selectedPlanselectedPlanselectedPlan");
  const formik = useFormik({
    initialValues: {
      name: "",
      cardNumber: "",
      expiryDate: "",
      cvv: "",
    },
    validationSchema: paySchema,
    onSubmit: async (values) => {
      // Implement payment logic here
      console.log("Processing payment...", values);
      try {
        const res = await addCard({
          userId: user._id,
          data: { ...values, subscriptionPlan: selectedPlan.id },
        }).unwrap();
        showToast("You have successfully subscribed to a plan");
        router.push("/dashboard/profile");
        dispatch(
          setCredentials({
            user: { ...user, ...res.data.data },
            token,
          })
        );
      } catch (e) {
        console.log(e, "e");
      }
    },
  });
  // console.log(formik, "formik");
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Box
            className="flex align-items-center justify-content-center"
            // sx={{ minHeight: "88vh" }}
            sx={{ minHeight: { xs: "100%", md: "88vh" } }}
          >
            <SharedLayout>
              <Box>
                <Typography
                  variant="h5"
                  className="fw-500 text-center"
                  sx={{ pb: 3 }}
                >
                  Pay with card
                </Typography>
                <Box sx={{ pb: 3 }} className="flex justify-content-between">
                  <FormControl>
                    <RadioGroup
                      aria-labelledby="demo-radio-buttons-group-label"
                      defaultValue="credit"
                      name="radio-buttons-group"
                      sx={{
                        span: {
                          fontWeight: "500",
                        },
                      }}
                    >
                      <FormControlLabel
                        value="credit"
                        control={<Radio />}
                        label="Credit or Debit Card"
                      />
                    </RadioGroup>
                  </FormControl>
                  <Box>
                    <Image
                      src="/assets/svg/visa.svg"
                      alt="visa"
                      width={40}
                      height={40}
                    />
                    <Image
                      src="/assets/svg/master_card.svg"
                      alt="visa"
                      width={40}
                      height={40}
                    />
                  </Box>
                </Box>
                <Box>
                  <form onSubmit={formik.handleSubmit}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={12}>
                        <Box sx={{ pb: 2 }}>
                          <InputLabel sx={{ py: 0.5, color: "#49454F" }}>
                            Cardholder Name
                          </InputLabel>
                          <Input
                            fullWidth
                            id="name"
                            name="name"
                            value={formik.values.name}
                            onChange={(e) => {
                              formik.handleChange(e);
                            }}
                            error={
                              formik.touched.name && Boolean(formik.errors.name)
                            }
                            helperText={
                              formik.touched.name && formik.errors.name
                            }
                            placeholder="e.g John Doe"
                          />
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={12}>
                        <Box sx={{ pb: 2 }}>
                          <InputLabel sx={{ py: 0.5, color: "#49454F" }}>
                            Card Number
                          </InputLabel>
                          <Input
                            fullWidth
                            id="cardNumber"
                            name="cardNumber"
                            value={formatCardNumber(formik.values.cardNumber)}
                            onChange={(e) => {
                              e.target.value = formatCardNumber(e.target.value);
                              formik.handleChange(e);
                            }}
                            error={
                              formik.touched.cardNumber &&
                              Boolean(formik.errors.cardNumber)
                            }
                            helperText={
                              formik.touched.cardNumber &&
                              formik.errors.cardNumber
                            }
                            sx={{
                              "& .MuiInputBase-root": {
                                paddingLeft: "8px",
                              },
                            }}
                            inputProps={{ maxLength: 19 }}
                            placeholder="1234 1234 1234 1234"
                            // placeholder="e.g John Doe"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="end">
                                  <IconButton edge="end" sx={{ p: 0 }}>
                                    {/* <CreditCard className="main-color" /> */}
                                    <Image
                                      src="/assets/svg/card.svg"
                                      width={22}
                                      height={22}
                                      alt="card"
                                    />
                                  </IconButton>
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <InputLabel sx={{ py: 0.5, color: "#49454F" }}>
                          Expiry Date
                        </InputLabel>
                        <Input
                          variant="outlined"
                          fullWidth
                          id="expiryDate"
                          name="expiryDate"
                          value={formik.values.expiryDate}
                          onChange={(e) => {
                            e.target.value = formatExpiryDate(e.target.value);
                            formik.handleChange(e);
                          }}
                          error={
                            formik.touched.expiryDate &&
                            Boolean(formik.errors.expiryDate)
                          }
                          helperText={
                            formik.touched.expiryDate &&
                            formik.errors.expiryDate
                          }
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <IconButton edge="end">
                                  <CalendarToday
                                    sx={{ color: "#ABABAB", width: "1rem" }}
                                  />
                                </IconButton>
                              </InputAdornment>
                            ),
                          }}
                          placeholder="MM/YY"
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <InputLabel sx={{ py: 0.5, color: "#49454F" }}>
                          CVV
                        </InputLabel>
                        <Input
                          variant="outlined"
                          fullWidth
                          id="cvv"
                          name="cvv"
                          value={formik.values.cvv}
                          onChange={formik.handleChange}
                          error={
                            formik.touched.cvv && Boolean(formik.errors.cvv)
                          }
                          helperText={formik.touched.cvv && formik.errors.cvv}
                          inputProps={{ maxLength: 4 }}
                          placeholder="e.g 1234"
                        />
                      </Grid>
                    </Grid>

                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      sx={{ width: "100%", mt: 4, py: 1.3, fontWeight: "500" }}
                      className="normal-text"
                    >
                      Pay Now ${selectedPlan && selectedPlan.price}
                    </Button>
                  </form>
                </Box>
              </Box>
            </SharedLayout>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              py: 4,
              background: "var(--light-grey)",
              minHeight: { xs: "100%", md: "88vh" },
              height: "100%",
            }}
            className="flex align-items-center"
          >
            <Box
              sx={{ maxWidth: "26rem", px: 2, margin: "auto", height: "100%" }}
            >
              {Object.keys(selectedPlan).length > 0 && (
                <PlanCard plan={selectedPlan} />
              )}
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default Pay;
