"use client";
import React from "react";
import { Container, Grid, Typography } from "@mui/material";
import { plansData } from "@/data/index";
import PlanCard from "@/components/shared/cards/PlanCard";

const Plan = () => {
  return (
    <>
      <Typography
        variant="h5"
        className="fw-500 text-center"
        sx={{ pb: 2, pt: 8 }}
      >
        Pricing Plans
      </Typography>
      <Typography
        variant="subtitle2"
        className="secondary-color text-center"
        sx={{ pb: 4 }}
      >
        Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et quasi
        iusto modi velit ut non voluptas in
      </Typography>
      <Container sx={{ pb: 9 }}>
        <Grid container spacing={2}>
          {plansData.map((plan) => (
            <Grid item xs={12} md={4} key={plan}>
              <PlanCard plan={plan} buy={true} />
            </Grid>
          ))}
        </Grid>
      </Container>
    </>
  );
};

export default Plan;
