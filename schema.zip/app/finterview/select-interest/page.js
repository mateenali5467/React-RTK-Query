"use client";
import React, { useRef, useState } from "react";
import Layout from "@/components/layouts/SharedLayout";
import { Box, Button, Chip, IconButton, Typography } from "@mui/material";
import { ArrowForwardIos, Done, ShowChart } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { useUpdateUserMutation } from "@/api/userAPI";
import FullScreenLoader from "@/components/shared/loaders/FullScreenLoader";
import { setCredentials } from "@/redux/slices/auth/authSlice";
import useToast from "@/hooks/useToast";
import { useRouter } from "next/navigation";
const chipData = [
  { id: 1, label: "Chip 1" },
  { id: 2, label: "Chip 2" },
  { id: 3, label: "Chip 3" },
  { id: 4, label: "Chip 3" },
  { id: 5, label: "Chip 3" },
  { id: 6, label: "Chip 3" },
  { id: 7, label: "Chip 3" },
  { id: 8, label: "Chip 3" },
];
const Interest = () => {
  const { showToast } = useToast();
  const dispatch = useDispatch();
  const router = useRouter();
  const { user, token } = useSelector((state) => state.auth);
  const [selectedChips, setSelectedChips] = useState([]);
  const [updateUser, { isLoading, isError, error, isSuccess, ...rest }] =
    useUpdateUserMutation();
  // const chipsContainerRef = useRef(null);
  console.log(user, "selectedChips");
  const handleChipClick = (chipLabel) => {
    if (selectedChips.includes(chipLabel)) {
      // If chip is already selected, remove it from the array
      setSelectedChips((prevSelectedChips) =>
        prevSelectedChips.filter((label) => label !== chipLabel)
      );
    } else {
      // If chip is not selected, add it to the array
      setSelectedChips((prevSelectedChips) => [
        ...prevSelectedChips,
        chipLabel,
      ]);
    }
  };
  const onNext = async () => {
    if (selectedChips.length === 0) {
      showToast("Please select atleast one interest", "error");
      return;
    }
    try {
      const res = await updateUser({
        userId: user._id,
        updatedUser: { interests: selectedChips },
      }).unwrap();
      dispatch(setCredentials({ user: res.data, token }));
      if (!user.customerId) {
        router.push("/finterview/payment/plan");
      } else {
        router.push("/dashboard/profile");
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Layout interest>
        <Typography variant="h5" className="fw-500 text-center" sx={{ pb: 4 }}>
          Select your interest
        </Typography>
        <Box
          sx={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            alignitems: "center",
          }}
        >
          {user &&
            user.interests &&
            user.interests.map((chip) => (
              <Chip
                key={chip.label}
                label={chip.label}
                clickable
                onClick={() => handleChipClick(chip.label)}
                // color={selectedChips.includes(chip.id) ? "primary" : "warning"}
                sx={{
                  fontWeight: "500",
                  margin: "5px",
                  backgroundColor: selectedChips.includes(chip.label)
                    ? "var(--main-color)"
                    : "#fff",
                  color: selectedChips.includes(chip.label) ? "#fff" : "#000",
                  "&:hover": {
                    color: selectedChips.includes(chip.label) && "#000",
                  },
                  "&:hover .MuiSvgIcon-root": {
                    color:
                      selectedChips.includes(chip.label) && "#000 !important",
                  },
                }}
                icon={
                  <IconButton size="small">
                    {selectedChips.includes(chip.label) && (
                      <Done sx={{ color: "#fff", width: "1rem" }} />
                    )}
                  </IconButton>
                }
                // onDelete={() => console.log(`Deleted Chip ${chip.label}`)}
              />
            ))}
        </Box>
        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <Button
            variant="contained"
            color="primary"
            sx={{ mt: 17, px: 3 }}
            endIcon={<ArrowForwardIos sx={{ width: "1rem" }} />}
            onClick={onNext}
            className="normal-text"
          >
            Next
          </Button>
        </Box>
      </Layout>
    </>
  );
};

export default Interest;
