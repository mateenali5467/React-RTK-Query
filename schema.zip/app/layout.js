import { Inter } from "next/font/google";
import "../styles/globals.css";
import { Providers } from "@/redux/provider/provider";
import SessionProvider from "@/components/auth/Providers";
const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Finterview",
  description: "Generated",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      {/* className={inter.className} */}
      <body>
        <Providers>
          <SessionProvider>{children}</SessionProvider>
        </Providers>
      </body>
    </html>
  );
}
