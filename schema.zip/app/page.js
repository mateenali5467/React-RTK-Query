"use client";
import React, { useState } from "react";
import {
  Calendar,
  dateFnsLocalizer,
  Views,
  DateLocalizer,
} from "react-big-calendar";
import { Box, Grid } from "@mui/material";
import enUS from "date-fns/locale/en-US";
import { format, isSameDay, parse, startOfWeek, getDay } from "date-fns";
import Container from "@/components/layouts/Container";
import ContentBlock from "@/components/shared/headings/ContentBlock";
import "react-big-calendar/lib/css/react-big-calendar.css";
import dayjs from "dayjs";
import { Delete, EdgesensorHigh } from "@mui/icons-material";
const events = [
  {
    title: "Meeting 1",
    start: new Date(2023, 10, 15, 10, 0),
    end: new Date(2023, 10, 15, 11, 0),
  },
  {
    title: "Meeting 2",
    start: new Date(2023, 10, 15, 10, 0),
    end: new Date(2023, 10, 15, 11, 0),
  },
  // Add more events as needed
];
const locales = {
  "en-US": enUS,
};
export default function Home() {
  const localizer = dateFnsLocalizer({
    format,
    parse,
    startOfWeek,
    getDay,
    locales,
  });

  const [selectedDate, setSelectedDate] = useState(null);

  const handleDateSelect = ({ start, end }) => {
    setSelectedDate(start);
  };

  const handleNavigate = (action) => {
    console.log("Navigate Action:", action);
  };

  const handleSelectSlot = (slotInfo) => {
    console.log("Selected Slot Info:", slotInfo);
  };

  const handleSelectEvent = (event, e) => {
    console.log("Selected Event:", event);
  };

  const handleDoubleClickEvent = (event, e) => {
    console.log("Double Clicked Event:", event);
  };

  const handleKeyPressEvent = (...args) => {
    console.log("Key Pressed Event:", args);
  };

  const handleDrillDown = (date, view) => {
    console.log("Drill Down:", date, view);
  };

  const handleGetDrilldownView = (
    targetDate,
    currentViewName,
    configuredViewNames
  ) => {
    console.log(
      "Get Drilldown View:",
      targetDate,
      currentViewName,
      configuredViewNames
    );
  };

  const eventStyleGetter = (event, start, end, isSelected) => {
    return {
      style: {
        backgroundColor: "blue",
      },
    };
  };
  const CustomToolbar = (toolbar) => {
    const goToBack = () => {
      toolbar.onNavigate("PREV");
    };

    const goToNext = () => {
      toolbar.onNavigate("NEXT");
    };

    return (
      <div className="custom-toolbar">
        <div>
          <Delete onClick={goToBack} />
        </div>
        <div>
          <strong>{toolbar.label}</strong>
        </div>
        <div>
          <EdgesensorHigh onClick={goToNext} />
        </div>
      </div>
    );
  };
  return (
    <>
     
    </>
  );
}
