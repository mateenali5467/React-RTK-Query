import React from "react";
import { Box, Divider } from "@mui/material";

const DividerChip = ({ title }) => {
  return (
    <>
      <Box sx={{ py: 1.5, maxWidth: "15rem", margin: "0 auto" }}>
        <Divider
          sx={{
            "&::before, &::after": { borderColor: "#444444" },
            color: "#444444",
          }}
        >
          {title && title}
        </Divider>
      </Box>
    </>
  );
};

export default DividerChip;
