import React, { useState, useEffect } from "react";
import Image from "next/image";
import { Box } from "@mui/material";
import { signIn, signOut, useSession } from "next-auth/react";
import { useGoogleLoginMutation } from "@/api/authAPI";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import { sendError } from "next/dist/server/api-utils";
import { setCredentials } from "@/redux/slices/auth/authSlice";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import useToast from "@/hooks/useToast";
// import store from "@/redux/store";
const SocialLogin = () => {
  const { showToast } = useToast();
  const dispatch = useDispatch();
  const router = useRouter();
  const [googleLogin, { isLoading }] = useGoogleLoginMutation();
  const { data: session, status, ...rest } = useSession();
  console.log(session, "next auth session");
  console.log(rest, "next auth rest");
  useEffect(() => {
    if (session && status === "authenticated") {
      console.log("authenticated");
      gogLogin();
      // console.log(session, "session");
      // console.log(status, "status");
      // console.log(rest, "rest");
    }
  }, [session]);
  const gogLogin = async () => {
    try {
      const { user, token } = await googleLogin({
        token: session.access_token,
      }).unwrap();
      console.log("data", user);
      dispatch(setCredentials({ user, token }));
      // Check if all "selected" values are false
      const allSelectedFalse = user.interests.every(
        (interest) => !interest.selected
      );
      // Redirect based on the condition
      if (allSelectedFalse) {
        // Redirect to the interest page
        router.push("/finterview/select-interest");
        showToast("Please select your interests");
      } else {
        // You can redirect to another page or dispatch additional actions here
        router.push("/dashboard/profile");
      }
    } catch (error) {
      console.log("error", error);
      if (error?.data) {
        showToast(error?.data?.message, "error");
      }
      // console.error(":", error);
    }
  };
  // const [fetchOnButtonClick, setFetchOnButtonClick] = useState(false);

  // const {
  //   data: meetings,
  //   isLoading,
  //   isSuccess,
  //   isError,
  //   error,
  // } = useGoogleLoginQuery(fetchOnButtonClick);
  // if (session.status === "loading") {
  //   return <p>Loading....</p>;
  // }
  // if (session.status === "authenticated") {
  //   return <button onClick={() => signOut("google")}>Logout</button>;
  // }
  // if (session.status === "unauthenticated") {
  //   return <p>user un authenticated</p>;
  // }
  const onGoogleLogin = async () => {
    try {
      const res = await signIn("google");
      console.log(res, "google res");
    } catch (error) {
      console.log(error, "google error");
    }
  };
  // if (session && session.user) {
  //   return (
  //     <div className="flex gap-4 ml-auto">
  //       <p className="text-sky-600">{session.user.name}</p>
  //       <p className="text-sky-600">{session.user.token}</p>
  //       <button onClick={() => signOut()} className="text-red-600">
  //         Sign Out
  //       </button>
  //       {/* <Image
  //         onClick={onGoogleLogin}
  //         src="/assets/svg/google.svg"
  //         height={40}
  //         width={40}
  //         alt="google"
  //       /> */}
  //     </div>
  //   );
  // }
  const handleButtonClick = () => {
    // Set the state to true to trigger the API call
    setFetchOnButtonClick(!fetchOnButtonClick);
  };

  return (
    <>
      {/* <button onClick={handleButtonClick}>Fetch Data</button> */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          img: {
            margin: "0 0.5rem",
            cursor: "pointer",
          },
        }}
      >
        <Image
          onClick={() => signIn("facebook")}
          src="/assets/svg/facebook.svg"
          height={40}
          width={40}
          alt="facebook"
        />
        <Image
          onClick={onGoogleLogin}
          src="/assets/svg/google.svg"
          height={40}
          width={40}
          alt="google"
        />
        <Image
          src="/assets/svg/iphone.svg"
          height={40}
          width={40}
          alt="iphone"
        />
      </Box>
    </>
  );
};

export default SocialLogin;
