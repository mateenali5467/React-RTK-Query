import React from "react";
import { Box } from "@mui/material";
const Container = ({ children }) => {
  return (
    <>
      <Box sx={{ maxWidth: "90%", margin: "0 auto", py: 2 }}>{children}</Box>
    </>
  );
};

export default Container;
