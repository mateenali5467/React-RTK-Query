import { Box } from "@mui/material";
import React from "react";

const SharedLayout = ({ children, interest }) => {
  return (
    <>
      <Box sx={{ px: 2 }}>
        <Box
          sx={{
            background: "var(--light-grey)",
            py: 5,
            px: { xs: 3, md: 10 },
            maxWidth: `${interest ? "45rem" : "30rem"}`,
            margin: "0 auto",
            my: 5,
            borderRadius: "20px",
          }}
        >
          {children}
        </Box>
      </Box>
    </>
  );
};

export default SharedLayout;
