"use client";
import { useRouter, usePathname } from "next/navigation";
import { useSelector } from "react-redux";
import { selectCurrentToken } from "@/redux/slices/auth/authSlice";

const RequireAuth = ({ children }) => {
  const token = useSelector(selectCurrentToken);
  const router = useRouter();
  const pathname = usePathname();

  if (!token) {
    // Redirect to login if token is not present
    router.replace("/finterview/auth/sign-in", { from: pathname });
    return null; // Return null to prevent rendering the child components
  }

  return children;
};

export default RequireAuth;
