import React from "react";
import Image from "next/image";
import { Box, Button, Typography, Grid } from "@mui/material";
import { CalendarTodayOutlined, Circle } from "@mui/icons-material";
const CalenderCard = ({ icon = true }) => {
  console.log(icon, "iconss");
  return (
    <>
      <Box
        sx={{
          background: "var(--light-grey)",
          py: 3,
          px: 3,
          borderRadius: "20px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box className="flex align-items-center">
            <Image
              src="/assets/svg/avatar.svg"
              width={60}
              height={60}
              alt="avatar"
            />
            <Typography variant="h6" className="fw-bold" sx={{ pl: 1 }}>
              Allen Smith
            </Typography>
          </Box>
          {icon && (
            <span
              style={{
                width: "15px",
                height: "15px",
                background: "var(--main-color)",
                borderRadius: "50%",
                display: "inline-block",
              }}
            ></span>
          )}
        </Box>
        <Box sx={{ py: 2 }}>
          <Box>
            <Box className="flex align-items-center" sx={{ py: 0.5 }}>
              <CalendarTodayOutlined
                className="main-color"
                sx={{ width: "1.2rem" }}
              />
              <Typography
                variant="subtitle2"
                className="secondary-color"
                sx={{ pl: 1.5 }}
              >
                11:00 AM - 12:30 PM, Nov 27, 2023
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
              <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
              <Typography
                variant="subtitle2"
                className="secondary-color"
                sx={{ pl: 1.5 }}
              >
                13 Practice Interviews, 92% Reliability
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
              <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
              <Typography
                variant="subtitle2"
                className="secondary-color"
                sx={{ pl: 1.5 }}
              >
                Language: English, Dutch, Spanish
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
              <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
              <Typography
                variant="subtitle2"
                className="secondary-color"
                sx={{ pl: 1.5 }}
              >
                Focus: Long Only, Equity Research
              </Typography>
            </Box>
            {/* <Box
              sx={{
                pt: 2,
                display: "flex",
                width: "100%",
                justifyContent: "center",
              }}
            >
              <Button variant="contained">Join Meeting</Button>
            </Box> */}
            <Box
              sx={{
                pt: 2,
                display: "flex",
                width: "100%",
                justifyContent: "right",
              }}
            >
              <Button
                variant="outlined"
                sx={{
                  margin: "2px",
                }}
              >
                Cancel
              </Button>
              <Button
                variant="contained"
                sx={{
                  margin: "2px",
                }}
              >
                Join Meeting
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default CalenderCard;