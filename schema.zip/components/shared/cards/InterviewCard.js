import React from "react";
import Image from "next/image";
import { Box, Button, Typography, Tooltip } from "@mui/material";
import { CalendarTodayOutlined, Circle } from "@mui/icons-material";
import { format } from "date-fns";
import { useAcceptMeetingMutation } from "@/api/meetingAPI";
import FullScreenLoader from "../loaders/FullScreenLoader";
import useToast from "@/hooks/useToast";
const InterviewCard = ({ meeting, refetch }) => {
  const { showToast } = useToast();
  const [acceptMeeting, { isLoading, isError, error }] =
    useAcceptMeetingMutation();
  const onAcceptMeeting = async (meetingId) => {
    console.log(meetingId, "meetingId");
    try {
      const res = await acceptMeeting(meetingId).unwrap();
      // refetch();
      showToast("Meeting Accepted Successfully", "success");
    } catch (err) {
      console.log(err, "err");
      showToast(err.data.message, "error");
    }
  };
  return (
    <>
      {isLoading && <FullScreenLoader />}
      {meeting && (
        <Box
          sx={{
            background: "var(--light-grey)",
            py: 3,
            px: 3,
            borderRadius: "20px",
            height: "100%",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Box className="flex align-items-center">
              <Image
                src="/assets/svg/avatar.svg"
                width={60}
                height={60}
                alt="avatar"
              />
              <Typography variant="h6" className="fw-bold" sx={{ pl: 1 }}>
                {meeting?.user?.name}
              </Typography>
            </Box>
          </Box>
          <Box sx={{ py: 2 }}>
            <Box>
              <Box className="flex align-items-center" sx={{ py: 0.5 }}>
                <CalendarTodayOutlined
                  className="main-color"
                  sx={{ width: "1.2rem" }}
                />
                <Typography
                  variant="subtitle2"
                  className="secondary-color"
                  sx={{ pl: 1.5 }}
                >
                  {format(
                    new Date(`2022-01-01T${meeting.startTime}`),
                    "h:mm a"
                  )}
                  {` - `}
                  {format(new Date(`2022-01-01T${meeting.endTime}`), "h:mm a")}
                  {`, `}
                  {format(new Date(meeting.meetingDate), "MMM dd, yyyy")}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
                <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
                <Typography
                  variant="subtitle2"
                  className="secondary-color"
                  sx={{ pl: 1.5 }}
                >
                  13 Practice Interviews, 92% Reliability
                </Typography>
              </Box>
              <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
                <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
                <Tooltip
                  title={meeting?.user?.languages
                    .map((obj) => obj.label)
                    .join(", ")}
                  arrow
                >
                  <Typography
                    variant="subtitle2"
                    className="secondary-color"
                    sx={{ pl: 1.5 }}
                  >
                    Language:{" "}
                    <span>
                      {meeting?.user?.languages.length > 0 &&
                        meeting?.user?.languages
                          .slice(0, 2)
                          .map((lang, index) => (
                            <>
                              <img
                                alt={lang.label}
                                src={`https://img.mobiscroll.com/demos/flags/${lang.value}.png`}
                                style={{
                                  maxWidth: "1rem",
                                  marginRight: "5px",
                                }}
                              />
                              <span>
                                {lang.label}
                                {index !==
                                  meeting?.user?.languages.slice(0, 2).length -
                                    1 && ", "}
                              </span>
                            </>
                          ))}
                    </span>
                  </Typography>
                </Tooltip>
              </Box>
              <Box sx={{ display: "flex", alignItems: "center", py: 0.5 }}>
                <Circle sx={{ color: "var(--light-text)", width: "0.8rem" }} />
                <Tooltip title={meeting?.user?.interests.join(", ")} arrow>
                  <Typography
                    variant="subtitle2"
                    className="secondary-color"
                    sx={{ pl: 1.5 }}
                  >
                    Focus:{" "}
                    {meeting?.user?.interests.length > 0 &&
                      meeting?.user?.interests
                        .slice(0, 2)
                        .map((inter, index) => (
                          <React.Fragment key={index}>
                            {inter}
                            {index !==
                              meeting?.user?.interests.slice(0, 2).length - 1 &&
                              ", "}
                          </React.Fragment>
                        ))}
                  </Typography>
                </Tooltip>
              </Box>
              <Box sx={{ pt: 2 }}>
                <Button
                  variant="contained"
                  sx={{
                    background: "transparent",
                    color: "var(--main-color)",
                    border: "1px solid var(--light-text)",
                    boxShadow: "none",
                    width: "100%",
                    py: 1.05,
                    borderRadius: "9px",
                    "&:hover": {
                      background: "transparent",
                    },
                  }}
                  onClick={() => onAcceptMeeting(meeting._id)}
                >
                  Accept Meeting
                </Button>
              </Box>
            </Box>
          </Box>
        </Box>
      )}
    </>
  );
};

export default InterviewCard;
