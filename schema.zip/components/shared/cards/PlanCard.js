"use client";

import React, { useState } from "react";
import { Done } from "@mui/icons-material";
import {
  Box,
  Button,
  Card,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { useUpdatePlanMutation } from "@/api/paymentAPI";
import { useSelector, useDispatch } from "react-redux";
import FullScreenLoader from "../loaders/FullScreenLoader";
import { setCredentials } from "@/redux/slices/auth/authSlice";
import useToast from "@/hooks/useToast";
const PlanCard = ({ plan, buy = false }) => {
  const router = useRouter();
  const { showToast } = useToast();
  const dispatch = useDispatch();
  const { user, token } = useSelector((state) => state.auth);
  console.log(user, "user");
  const [updatePlan, { isLoading, error, isError }] = useUpdatePlanMutation();
  const [selectedPlan, setSelectedPlan] = useState(null);
  console.log(error, "error");

  // if (isError) {
  //   showToast(error.data.message, "error");
  // }

  const handlePlanClick = (plan) => {
    if (buy) {
      // setSelectedPlan(plan.type === selectedPlan ? null : plan.type);
    }
  };

  const onBuy = async (plan) => {
    console.log(plan, "plan");
    // let sub = 1;
    // if (plan === "Edge") {
    //   sub = 2;
    // } else if (plan === "Excellence") {
    //   sub = 3;
    // }

    if (user.customerId) {
      try {
        const res = await updatePlan({
          userId: user._id,
          subscriptionPlan: { subscriptionPlan: plan.id },
        }).unwrap();
        console.log(res, "res.data.customerId");
        if (res.subscriptionPlan) {
          dispatch(
            setCredentials({
              user: { ...user, subscriptionPlan: res.subscriptionPlan },
              token,
            })
          );
          router.push("/dashboard/profile");
          showToast("You have successfully upgrade to a plan");
        }
      } catch (e) {
        console.log(e, "e");
        if (e?.data?.message) {
          showToast(e?.data?.message, "error");
        }
      }
    } else {
      let params = new URLSearchParams(window.location.search);
      params.set("plan", plan.type);
      router.push(`/finterview/payment/pay?${params}`);
      // const res = await createCustomer({
      //   userId: user._id,
      //   subscriptionPlan: { subscriptionPlan: sub },
      // });
      // console.log(res.data.customerId, "res.data.customerId");
      // dispatch(
      //   setCredentials({
      //     user: { ...user, customerId: res.data.customerId },
      //     token,
      //   })
      // );
    }
  };
  return (
    <>
      {isLoading && <FullScreenLoader />}
      <Card
        sx={{
          boxShadow: "none",
          borderRadius: "15px",
          //   height: "100%",
          border:
            plan.type === selectedPlan
              ? "1px solid #ABABAB"
              : "1px solid #ABABAB",
          px: 3.5,
          py: 3.5,
          backgroundColor: plan.type === selectedPlan && "#F7F7F7",
          cursor: "pointer",
          "&:hover": {
            backgroundColor: "#F7F7F7",
            transition: "0.5s ease-in-out",
          },
          "&:hover .MuiButton-root": {
            backgroundColor: "var(--main-color)",
            color: "#fff",
            border: "1px solid var(--main-color)",
          },
        }}
        onClick={() => handlePlanClick(plan)}
        key={plan.type}
      >
        <Box sx={{ p: 0 }}>
          <Typography variant="h6" component="div" className="fw-500">
            {plan.type}
          </Typography>
          <Typography
            variant="caption"
            className="secondary-color fw-500"
            sx={{ py: 2 }}
          >
            Distinctio et nulla eum soluta et neque labore quibusdAM. Saepe et
            quasi iusto modi velit ut non
          </Typography>

          <Typography
            variant="h5"
            component="div"
            className="fw-500 main-color"
            sx={{ display: "flex", alignItems: "center" }}
          >
            ${plan.price}
            <Typography
              variant="subtitle2"
              className="secondary-color"
              component="span"
              sx={{ pl: "5px !iMPORTANT" }}
            >
              /months
            </Typography>
          </Typography>

          <List sx={{ p: 0, pt: 3 }}>
            {plan.points.map((point, index) => (
              <ListItem key={index} sx={{ px: 0 }}>
                <ListItemIcon sx={{ minWidth: "35px" }}>
                  <Done className="main-color" />
                </ListItemIcon>
                <ListItemText
                  primary={point}
                  sx={{
                    span: {
                      fontSize: "14px !iMPORTANT",
                      color: "var(--secondary-color) !iMPORTANT)",
                      fontWeight: "500 !iMPORTANT",
                    },
                  }}
                  // secondary={secondary ? "Secondary text" : null}
                />
              </ListItem>
            ))}
          </List>
          {buy && (
            <Box sx={{ pt: 3 }}>
              <Button
                variant="contained"
                sx={{
                  width: "100%",
                  backgroundColor: "transparent",
                  color: "var(--main-color)",
                  boxShadow: "none",
                  border: "1px solid var(--border-color)",
                  py: 1,
                }}
                className="normal-text"
                onClick={() => onBuy(plan)}
              >
                Buy Now
              </Button>
            </Box>
          )}
        </Box>
      </Card>
    </>
  );
};

export default PlanCard;
