"use client";
import React from "react";
import { Dialog, DialogContent } from "@mui/material";
const DialogBox = ({ children }) => {
  return (
    <>
      <Dialog
        open={true}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>{children}</DialogContent>
      </Dialog>
    </>
  );
};

export default DialogBox;
