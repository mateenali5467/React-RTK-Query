import { Box, Typography } from "@mui/material";
import React from "react";

const ContentBlock = ({ title, description }) => {
  return (
    <Box>
      <Typography variant="h5" className="fw-500">
        {title}
      </Typography>
      <Typography
        variant="subtitle2"
        className="fw-500"
        sx={{
          pt: 1,
          color: "#49454F",
        }}
      >
        {description}
      </Typography>
    </Box>
  );
};

export default ContentBlock;
