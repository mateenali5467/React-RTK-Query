"use client";

import {
  Avatar,
  Box,
  Divider,
  IconButton,
  ListItemIcon,
  Menu,
  MenuItem,
  Tab,
  Tabs,
  Toolbar,
  Tooltip,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import React, { useEffect } from "react";
import MobileDrawer from "./MobileDrawer";
import { pages } from "@/data";
import { usePathname, useRouter } from "next/navigation";
import Container from "@/components/layouts/Container";
import { Logout, PersonAdd, Settings } from "@mui/icons-material";
import { useGetUserQuery } from "@/api/userAPI";
import { selectCurrentUser } from "@/redux/slices/auth/authSlice";
import { useSelector, useDispatch } from "react-redux";
import Link from "next/link";
import { logOut } from "@/redux/slices/auth/authSlice";
import { FiberManualRecordRounded } from "@mui/icons-material";
import { signOut, useSession } from "next-auth/react";

const DashboardNavbar = () => {
  const dispatch = useDispatch();
  const pathname = usePathname();
  const router = useRouter();
  const theme = useTheme();
  const { status } = useSession();
  const user = useSelector(selectCurrentUser);
  const isMatch = useMediaQuery(theme.breakpoints.down("lg"));
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const onLogout = () => {
    router.push("/finterview/auth/sign-in");
    if (status === "authenticated") {
      signOut();
    }
    dispatch(logOut());
  };
  return (
    <>
      <Box sx={{ position: "sticky", top: 0, zIndex: 999, background: "#fff" }}>
        <Container>
          <Toolbar
            sx={{
              padding: "0 !important",
              minHeight: "auto !important",
              justifyContent: "space-between",
              flexWrap: { xs: "wrap", lg: "nowrap" },
              position: "sticky",
              top: 0,
            }}
          >
            <Box className="flex align-items-center">
              {isMatch && (
                <Box sx={{ pr: 2 }}>
                  <MobileDrawer />
                </Box>
              )}
              <Link
                href="/dashboard/calendar"
                style={{ textDecoration: "none" }}
              >
                <Typography
                  variant="h5"
                  sx={{ color: "var(--main-color)", fontWeight: "500" }}
                >
                  FinterviewPrep
                </Typography>
              </Link>
            </Box>

            {isMatch ? (
              <></>
            ) : (
              <Tabs
                // sx={{ marginLeft: "auto" }}
                indicatorColor="primary"
                // textColor="#fff"
                // value={value}
                // selected={true}
                // onChange={(e, value) => setValue(value)}
                sx={{
                  "& .MuiTab-root": {
                    color: "#000",
                    fontSize: "12px",
                    fontWeight: "bold",
                    textTransform: "none", // Add this line to set text transform to normal
                  },
                }}
              >
                {pages.map((page, index) => (
                  <Tab
                    key={index}
                    label={page.name}
                    onClick={() => router.push(page.navigate)}
                    sx={{
                      position: "relative",
                      color: `${
                        page.navigate === pathname &&
                        "var(--main-color) !important"
                      }`,
                    }}
                    icon={
                      page.navigate === pathname && (
                        <FiberManualRecordRounded
                          sx={{
                            position: "absolute",
                            bottom: "0px",
                            width: "1rem",
                            color: "var(--main-color)",
                          }}
                        />
                      )
                    }
                    iconPosition="bottom"
                  />
                ))}
              </Tabs>
            )}
            <Box sx={{ pl: 1.5 }}>
              <Box className="flex align-items-center">
                {!isMatch && (
                  <Typography variant="subtitle2" className="fw-500">
                    {user?.name}
                  </Typography>
                )}
                <Tooltip title="Profile settings">
                  <IconButton
                    onClick={handleClick}
                    size="small"
                    aria-controls={open ? "account-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? "true" : undefined}
                  >
                    <Avatar
                      sx={{ width: 32, height: 32 }}
                      src={
                        user?.image
                          ? user?.image
                          : "/assets/images/user-avator.png"
                      }
                    />
                  </IconButton>
                </Tooltip>
              </Box>

              <Menu
                anchorEl={anchorEl}
                id="account-menu"
                open={open}
                onClose={handleClose}
                onClick={handleClose}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
                sx={{
                  li: {
                    color: "var(--secondary-color)",
                    fontWeight: "500",
                  },
                  a: {
                    textDecoration: "none",
                    color: "var(--secondary-color)",
                  },
                }}
              >
                <MenuItem onClick={handleClose}>
                  <Link href="/dashboard/profile">My Profile</Link>
                </MenuItem>
                <MenuItem onClick={handleClose}>
                  <Link href="/finterview/payment/plan">Membership</Link>
                </MenuItem>
                <MenuItem onClick={handleClose}>
                  <Link href="/finterview/payment/plan">About Us</Link>
                </MenuItem>
                <MenuItem onClick={handleClose}>
                  <span onClick={onLogout}>Log out</span>
                </MenuItem>
              </Menu>
            </Box>
          </Toolbar>
        </Container>
        <Divider />
      </Box>
    </>
  );
};

export default DashboardNavbar;
