"use client";

import { Box, Container, Divider, Typography } from "@mui/material";
import React from "react";
import Link from "next/link";
const Navbar = () => {
  return (
    <>
      <Box
        sx={{ position: "sticky", top: "0", background: "#fff", zIndex: 99 }}
      >
        <Container sx={{ py: 2 }}>
          <Link
            href="/finterview/auth/sign-in"
            style={{ textDecoration: "none" }}
          >
            <Typography
              variant="h5"
              sx={{ color: "var(--main-color)", fontWeight: "500" }}
            >
              FinterviewPrep
            </Typography>
          </Link>
        </Container>
        <Divider />
      </Box>
    </>
  );
};

export default Navbar;
