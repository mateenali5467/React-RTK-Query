"use client";
import React, { useState } from "react";
import {
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import { Menu } from "@mui/icons-material";
import { useRouter } from "next/navigation";
import { pages } from "@/data";
import Link from "next/link";

const MobileDrawer = () => {
  const router = useRouter();
  const [openDrawer, setOpenDrawer] = useState(false);
  return (
    <>
      <Drawer
        // sx={{ background: "#000" }}
        anchor="left"
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
      >
        {/* <Link href="/dashboard/calendar" style={{ textDecoration: "none"  , paddingLeft:"1.1rem"}}>
          <Typography
            variant="h5"
            sx={{ color: "var(--main-color)", fontWeight: "500" }}
          >
            FinterviewPrep
          </Typography>
        </Link> */}

        <List sx={{ height: "100%" }}>
          {pages.map((page, index) => (
            <ListItemButton
              key={index}
              onClick={() => router.push(page?.navigate)}
            >
              <ListItemIcon>
                <ListItemText sx={{ color: "var(--main-color)" }}>
                  {page.name}
                </ListItemText>
              </ListItemIcon>
            </ListItemButton>
          ))}
        </List>
      </Drawer>
      <IconButton
        sx={{ color: "var(--secondary-color)", marginLeft: "auto" }}
        onClick={() => setOpenDrawer(!openDrawer)}
      >
        <Menu color="white" />
      </IconButton>
    </>
  );
};

export default MobileDrawer;
