export const plansData = [
  {
    type: "Explorer",
    price: 0,
    id: 1,
    points: [
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta et",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
    ],
  },
  {
    type: "Edge",
    price: 9,
    id: 2,
    points: [
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta et",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
    ],
  },
  {
    type: "Excellence",
    price: 30,
    id: 3,
    points: [
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta et",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
      "Distinctio et nulla eum soluta",
    ],
  },
];

export const pages = [
  {
    name: "Home",
    navigate: "/dashboard/calendar",
  },
  {
    name: "My Meetings",
    navigate: "/dashboard/my-meetings",
  },
  {
    name: "Practice Interviews",
    navigate: "/dashboard/schedule-practice-interviews",
  },
  // {
  //   name: "Question Generator",
  //   navigate: "/category",
  // },
  // {
  //   name: "Learning Material",
  //   navigate: "/category",
  // },
  // {
  //   name: "Learning Material",
  //   navigate: "/Resources",
  // },
];
