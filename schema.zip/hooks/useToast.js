// hooks/useToast.js
import { useToaster } from "react-hot-toast";
import toast from "react-hot-toast";

const useToast = () => {
  // const toaster = useToaster();

  const showToast = (message, type = "success") => {
    const options = {
      duration: 3000,
      position: "top-right",
    };

    if (type === "success") {
      toast.success(message, options);
    } else if (type === "error") {
      toast.error(message, options);
    }
    // You can add more conditions for other types if needed

    // If you want a default case for unrecognized types:
    // else {
    //   toaster(message, options);
    // }
  };

  return {
    showToast,
  };
};

export default useToast;
