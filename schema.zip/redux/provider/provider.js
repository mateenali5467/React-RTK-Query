"use client";

import { store, persistor } from "../store/store";
import { Provider } from "react-redux";
import { Toaster } from "react-hot-toast";
import { PersistGate } from "redux-persist/integration/react";
import { SessionProvider } from "next-auth/react";
export function Providers({ children }) {
  return (
    <Provider store={store}>
      <Toaster />
      <SessionProvider>
        <PersistGate loading={null} persistor={persistor}>
          {children}
        </PersistGate>
      </SessionProvider>
    </Provider>
  );
}
