"use client";
import { combineReducers, configureStore } from "@reduxjs/toolkit";
import authReducer from "../slices/auth/authSlice";
import { productApi } from "@/api/productAPI";
import { userApi } from "@/api/userAPI";
import { authApi } from "@/api/authAPI";
import { meetingApi } from "@/api/meetingAPI";
import { paymentApi } from "@/api/paymentAPI";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage"; // defaults to localStorage for web
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["auth"], // List of reducers to persist
};
const rootReducer = combineReducers({
  auth: authReducer,
  [authApi.reducerPath]: authApi.reducer,
  [productApi.reducerPath]: productApi.reducer,
  [userApi.reducerPath]: userApi.reducer,
  [meetingApi.reducerPath]: meetingApi.reducer,
  [paymentApi.reducerPath]: paymentApi.reducer,

  //add all your reducers here
});
const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  devTools: process.env.NODE_ENV !== "production",
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      productApi.middleware,
      authApi.middleware,
      userApi.middleware,
      meetingApi.middleware,
      paymentApi.middleware
    ),
  // middleware: (getDefaultMiddleware) => getDefaultMiddleware({}).concat([]),
});
// export const store = configureStore({
//   reducer: {
//     auth: authReducer,
//   },
//   devTools: process.env.NODE_ENV !== "production",
// });
export const persistor = persistStore(store);
