import * as yup from "yup";

export const loginSchema = yup.object({
  email: yup
    .string("Enter your email")
    .email("Enter a valid email")
    .required("Email is required"),
  password: yup.string("Enter your password").required("Password is required"),
});

export const signupSchema = yup.object().shape({
  name: yup
    .string()
    .matches(
      /^[a-zA-Z]+([ ]?[a-zA-Z]+)?$/,
      "Full Name must be a alphabets only"
    )
    .required("Full Name is required"),
  email: yup
    .string()
    .email("Invalid email")
    .matches(/^[^@]+@[^@]+\.[a-zA-Z]{2,}$/, "Invalid email format")
    .required("Email is required"),
  password: yup
    .string()
    .min(8, "Password must be at least 8 characters")
    .matches(
      /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
      "Password must contain at least one uppercase letter, one digit, one special character and must be at least 8 characters"
    )
    .required("Password is required"),
  // confirmPassword: yup
  //   .string()
  //   .oneOf([yup.ref("password"), null], "Passwords must match")
  //   .required("Confirm Password is required"),
});
export const forgotSchema = yup.object().shape({
  email: yup.string().email("Invalid email").required("Email is required"),
});
export const resetPasswordSchema = yup.object().shape({
  password: yup
    .string()
    .min(8, "Password must be at least 8 characters")
    .required("Password is required"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("password"), null], "Passwords must match")
    .required("Confirm Password is required"),
});

export const paySchema = yup.object({
  cardNumber: yup
    .string()
    // .matches(/^[0-9]{16}$/, "Invalid card number")
    .required("Card number is required"),
  expiryDate: yup.string().required("Expiry date is required"),
  name: yup.string().required("Name is required"),
  cvv: yup
    .string()
    .matches(/^[0-9]{3,4}$/, "Invalid CVV")
    .required("CVV is required"),
});

export const createMeetingSchema = yup.object({
  title: yup.string().required("Title is required"),
  meetingDate: yup.date().required("Date is required"),
  startTime: yup.string().required("Time is required"),
  interests: yup.array().min(1, "Select at least one interest"),
  description: yup.string().required("Description is required"),
});

export const profileSchema = yup.object({
  // profilePic: yup
  //   .mixed()
  //   .required("Profile Picture is required")
  //   .test(
  //     "fileType",
  //     "Only JPEG and PNG file types are allowed",
  //     (value) => value && ["image/jpeg", "image/png"].includes(value.type)
  //   ),
  name: yup.string().required("Name is required"),
  interests: yup.array().min(1, "Select at least one interest"),
  languages: yup.array().min(1, "Select at least one language"),
  // plan: yup.string().required("Select a plan"),
});
