import styled from "styled-components";
import { Autocomplete } from "@mui/material";

export const AutocompleteStyled = styled(Autocomplete)`
  .MuiInputBase-root {
    border-radius: 11px;
    background-color: #fff;
    padding: 3px 10px;
  }

  .MuiChip-root {
    background: #2480f926 !important;
    font-weight: 600;
  }
`;
