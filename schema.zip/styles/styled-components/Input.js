import styled from "styled-components";
import { TextField } from "@mui/material";

export const Input = styled(TextField)`
  .MuiInputBase-root {
    border-radius: 11px;
  }
  input {
    padding: 12px 16px;
  }
  fieldset {
    /* background: ${(props) => (props.color ? props.color : "transparent")}; */
  }
`;
