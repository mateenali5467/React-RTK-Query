import styled from "styled-components";
import { Select } from "@mui/material";

export const MenuStyled = styled(Select)`
  border-radius: 12px;
  .MuiOutlinedInput-input {
    padding: 11px 14px;
    background: #fff;
  }
`;
