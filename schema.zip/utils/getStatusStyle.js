const getStatusStyle = (status) => {
  let statusColor;

  switch (status) {
    case "pending":
      statusColor = "#F6871A";
      break;
    case "accept":
      statusColor = "#41BE66";
      break;
    case "me":
      statusColor = "#2480F9";
      break;
    default:
      statusColor = "#2480F9";
  }

  return {
    color: statusColor,
  };
};

export default getStatusStyle;
